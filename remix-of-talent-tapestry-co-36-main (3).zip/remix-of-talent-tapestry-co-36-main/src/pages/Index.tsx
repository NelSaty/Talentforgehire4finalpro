import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  Rocket, 
  TrendingUp, 
  Award, 
  Zap, 
  Users, 
  Building2, 
  GraduationCap,
  ChevronRight,
  Star,
  CheckCircle2,
  Clock,
  DollarSign,
  ShoppingCart,
  FolderKanban,
  Package,
  Brain,
  BookOpen,
  Briefcase,
  FolderOpen,
  UserCheck
} from "lucide-react";
import { DeliverableMarketplace } from "@/components/employer/DeliverableMarketplace";
import { CustomProjectRequest } from "@/components/employer/CustomProjectRequest";
import { OrderTracking } from "@/components/employer/OrderTracking";
import { DeliverableDetails } from "@/components/employer/DeliverableDetails";
import { QualityAssurance } from "@/components/employer/QualityAssurance";
import { EscrowPayment } from "@/components/employer/EscrowPayment";
import { TalentPool } from "@/components/employer/TalentPool";
import { StudentBadges } from "@/components/student/StudentBadges";
import { AssessmentScores } from "@/components/student/AssessmentScores";
import { MentorAssignment } from "@/components/student/MentorAssignment";
import { PlacementStatistics } from "@/components/student/PlacementStatistics";
import { CompletedPortfolio } from "@/components/student/CompletedPortfolio";
import { TrainingMethodology } from "@/components/student/TrainingMethodology";

const Index = () => {
  const [activeView, setActiveView] = useState<"landing" | "student" | "employer">("landing");

  if (activeView === "student") {
    return <StudentDashboard onBack={() => setActiveView("landing")} />;
  }

  if (activeView === "employer") {
    return <EmployerDashboard onBack={() => setActiveView("landing")} />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-background via-background to-secondary/20">
      {/* Navigation */}
      <nav className="border-b border-border/40 backdrop-blur-sm sticky top-0 z-50 bg-background/80">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-primary/60 flex items-center justify-center">
              <Rocket className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="font-bold text-xl">TalentForge</span>
          </div>
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="sm">Sign In</Button>
            <Button size="sm" className="bg-gradient-to-r from-primary to-primary/80 hover:opacity-90">
              Get Started
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="container mx-auto px-4 pt-20 pb-16">
        <div className="max-w-4xl mx-auto text-center">
          <Badge className="mb-4 bg-primary/10 text-primary border-primary/20 hover:bg-primary/20">
            Assessment-Gated Apprenticeship Marketplace
          </Badge>
          <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-foreground to-foreground/70 bg-clip-text text-transparent">
            Where Talent Meets Opportunity
          </h1>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Earn while you learn. Progress through tiers. Get hired by top companies. 
            The marketplace where verified performance unlocks real opportunities.
          </p>
          <div className="flex flex-wrap gap-4 justify-center">
            <Button 
              size="lg" 
              className="bg-gradient-to-r from-primary to-primary/80 hover:opacity-90 shadow-lg"
              onClick={() => setActiveView("student")}
            >
              <GraduationCap className="mr-2 h-5 w-5" />
              For Students
              <ChevronRight className="ml-2 h-5 w-5" />
            </Button>
            <Button 
              size="lg" 
              variant="outline"
              onClick={() => setActiveView("employer")}
            >
              <Building2 className="mr-2 h-5 w-5" />
              For Employers
            </Button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-16 max-w-4xl mx-auto">
          {[
            { label: "Active Interns", value: "1,200+", icon: Users },
            { label: "Partner Companies", value: "150+", icon: Building2 },
            { label: "Avg. Monthly Earnings", value: "₹18K", icon: DollarSign },
            { label: "Placement Rate", value: "78%", icon: TrendingUp }
          ].map((stat, i) => (
            <Card key={i} className="p-6 text-center hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
              <stat.icon className="w-8 h-8 mx-auto mb-3 text-primary" />
              <div className="text-3xl font-bold mb-1">{stat.value}</div>
              <div className="text-sm text-muted-foreground">{stat.label}</div>
            </Card>
          ))}
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 bg-secondary/30">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">How It Works</h2>
          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {[
              {
                icon: Award,
                title: "1. Get Assessed",
                description: "Complete standardized assessment to verify skills and unlock your starting tier"
              },
              {
                icon: Zap,
                title: "2. Complete Micro-Sprints",
                description: "Work on real company projects, deliver milestones, and earn per validated output"
              },
              {
                icon: TrendingUp,
                title: "3. Progress & Get Hired",
                description: "Climb tiers based on performance metrics and unlock fast-track hiring opportunities"
              }
            ].map((step, i) => (
              <Card key={i} className="p-6 hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary to-primary/60 flex items-center justify-center mb-4">
                  <step.icon className="w-6 h-6 text-primary-foreground" />
                </div>
                <h3 className="font-bold text-xl mb-2">{step.title}</h3>
                <p className="text-muted-foreground">{step.description}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Tier System Preview */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-4">Transparent Tier System</h2>
          <p className="text-center text-muted-foreground mb-12 max-w-2xl mx-auto">
            Progress through levels by meeting clear performance metrics. Higher tiers unlock better projects and higher pay.
          </p>
          <div className="grid md:grid-cols-5 gap-4 max-w-6xl mx-auto">
            {[
              { name: "Trainee", color: "from-gray-400 to-gray-500", pay: "₹5-8K" },
              { name: "Contributor", color: "from-blue-400 to-blue-500", pay: "₹8-15K" },
              { name: "Associate", color: "from-purple-400 to-purple-500", pay: "₹15-25K" },
              { name: "Lead", color: "from-amber-400 to-amber-500", pay: "₹25-40K" },
              { name: "Fast-Track", color: "from-emerald-400 to-emerald-500", pay: "₹40K+" }
            ].map((tier, i) => (
              <Card key={i} className="p-6 hover:shadow-xl transition-all duration-300 hover:-translate-y-2">
                <div className={`w-12 h-12 rounded-full bg-gradient-to-br ${tier.color} mx-auto mb-3`} />
                <div className="text-center">
                  <div className="font-bold mb-1">{tier.name}</div>
                  <div className="text-sm text-success font-semibold">{tier.pay}/mo</div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-primary/10 via-primary/5 to-accent/10">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to Start Your Journey?</h2>
          <p className="text-muted-foreground mb-8 max-w-2xl mx-auto">
            Join thousands of engineering graduates who are earning, learning, and building careers through real work.
          </p>
          <Button size="lg" className="bg-gradient-to-r from-primary to-primary/80 hover:opacity-90 shadow-lg">
            Create Free Account
            <ChevronRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border/40 py-8 bg-secondary/20">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          <p>© 2025 TalentForge. Assessment-gated apprenticeship marketplace.</p>
        </div>
      </footer>
    </div>
  );
};

const StudentDashboard = ({ onBack }: { onBack: () => void }) => {
  const [activeTab, setActiveTab] = useState<"dashboard" | "assessments" | "badges" | "portfolio" | "mentors" | "training" | "placements">("dashboard");
  const currentTier = "Contributor";
  const progress = 68;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/40 sticky top-0 z-40 bg-background/95 backdrop-blur">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="sm" onClick={onBack}>← Back</Button>
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-primary/60 flex items-center justify-center">
                <Rocket className="w-5 h-5 text-primary-foreground" />
              </div>
              <span className="font-bold">TalentForge</span>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Badge className="bg-primary/10 text-primary border-primary/20">
              <Star className="w-3 h-3 mr-1" />
              {currentTier}
            </Badge>
            <Button size="sm" variant="outline">Profile</Button>
          </div>
        </div>
      </header>

      {/* Navigation Tabs */}
      <div className="border-b border-border/40 bg-background/95 backdrop-blur sticky top-16 z-30">
        <div className="container mx-auto px-4">
          <div className="flex gap-1 overflow-x-auto">
            {[
              { id: "dashboard", label: "Dashboard", icon: Zap },
              { id: "assessments", label: "Assessments", icon: Brain },
              { id: "badges", label: "Badges", icon: Award },
              { id: "portfolio", label: "Portfolio", icon: FolderOpen },
              { id: "mentors", label: "Mentors", icon: UserCheck },
              { id: "training", label: "Training", icon: BookOpen },
              { id: "placements", label: "Placements", icon: Briefcase }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 px-4 py-3 text-sm font-medium border-b-2 transition-colors whitespace-nowrap ${
                  activeTab === tab.id
                    ? "border-primary text-primary"
                    : "border-transparent text-muted-foreground hover:text-foreground"
                }`}
              >
                <tab.icon className="w-4 h-4" />
                {tab.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {activeTab === "dashboard" && (
          <div className="grid lg:grid-cols-3 gap-6">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-6">
              {/* Tier Progress */}
              <Card className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-xl font-bold">Your Progress to Associate</h2>
                  <span className="text-2xl font-bold text-primary">{progress}%</span>
                </div>
                <Progress value={progress} className="mb-4 h-3" />
                <div className="grid grid-cols-3 gap-4 text-sm">
                  <div>
                    <div className="text-muted-foreground mb-1">Acceptance Rate</div>
                    <div className="font-semibold text-success">74%</div>
                  </div>
                  <div>
                    <div className="text-muted-foreground mb-1">Quality Score</div>
                    <div className="font-semibold text-primary">82/100</div>
                  </div>
                  <div>
                    <div className="text-muted-foreground mb-1">Velocity</div>
                    <div className="font-semibold">4.2 days</div>
                  </div>
                </div>
              </Card>

              {/* Available Projects */}
              <div>
                <h2 className="text-xl font-bold mb-4">Available Micro-Sprints</h2>
                <div className="space-y-4">
                  {[
                    {
                      title: "Build REST API Authentication Module",
                      company: "TechCorp",
                      duration: "5-7 days",
                      payout: "₹8,500",
                      skills: ["Node.js", "JWT", "Express"],
                      difficulty: "Contributor"
                    },
                    {
                      title: "Create React Dashboard Components",
                      company: "StartupHub",
                      duration: "3-5 days",
                      payout: "₹6,000",
                      skills: ["React", "TypeScript", "Tailwind"],
                      difficulty: "Contributor"
                    },
                    {
                      title: "Implement Payment Gateway Integration",
                      company: "FinanceFlow",
                      duration: "7-10 days",
                      payout: "₹12,000",
                      skills: ["Node.js", "Stripe", "Webhooks"],
                      difficulty: "Associate"
                    }
                  ].map((project, i) => (
                    <Card key={i} className="p-6 hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h3 className="font-bold text-lg mb-1">{project.title}</h3>
                          <p className="text-sm text-muted-foreground">{project.company}</p>
                        </div>
                        <Badge variant="outline">
                          {project.difficulty}
                        </Badge>
                      </div>
                      <div className="flex flex-wrap gap-2 mb-4">
                        {project.skills.map((skill, j) => (
                          <Badge key={j} variant="secondary" className="text-xs">{skill}</Badge>
                        ))}
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4 text-sm">
                          <div className="flex items-center gap-1 text-muted-foreground">
                            <Clock className="w-4 h-4" />
                            {project.duration}
                          </div>
                          <div className="flex items-center gap-1 text-success font-semibold">
                            <DollarSign className="w-4 h-4" />
                            {project.payout}
                          </div>
                        </div>
                        <Button size="sm" disabled={i === 2}>
                          {i === 2 ? "Unlock at Associate" : "Apply Now"}
                        </Button>
                      </div>
                    </Card>
                  ))}
                </div>
              </div>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Earnings */}
              <Card className="p-6 bg-gradient-to-br from-success/10 to-success/5 border-success/20">
                <h3 className="font-bold mb-4">This Month's Earnings</h3>
                <div className="text-4xl font-bold text-success mb-2">₹14,250</div>
                <p className="text-sm text-muted-foreground mb-4">+₹3,200 from last month</p>
                <Button className="w-full bg-success hover:bg-success/90">
                  View Payout History
                </Button>
              </Card>

              {/* Achievements */}
              <Card className="p-6">
                <h3 className="font-bold mb-4">Recent Achievements</h3>
                <div className="space-y-3">
                  {[
                    { icon: CheckCircle2, text: "5 Sprints Completed", color: "text-success" },
                    { icon: TrendingUp, text: "Tier Upgraded", color: "text-primary" },
                    { icon: Award, text: "Quality Badge Earned", color: "text-amber-500" }
                  ].map((achievement, i) => (
                    <div key={i} className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-lg bg-secondary flex items-center justify-center ${achievement.color}`}>
                        <achievement.icon className="w-5 h-5" />
                      </div>
                      <span className="text-sm">{achievement.text}</span>
                    </div>
                  ))}
                </div>
              </Card>

              {/* Next Steps */}
              <Card className="p-6 bg-gradient-to-br from-primary/10 to-primary/5 border-primary/20">
                <h3 className="font-bold mb-3">Level Up to Associate</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  Complete 2 more sprints with 75%+ quality score
                </p>
                <Button variant="outline" className="w-full">View Requirements</Button>
              </Card>
            </div>
          </div>
        )}

        {activeTab === "assessments" && <AssessmentScores />}
        {activeTab === "badges" && <StudentBadges />}
        {activeTab === "portfolio" && <CompletedPortfolio />}
        {activeTab === "mentors" && <MentorAssignment />}
        {activeTab === "training" && <TrainingMethodology />}
        {activeTab === "placements" && <PlacementStatistics />}
      </div>
    </div>
  );
};

const EmployerDashboard = ({ onBack }: { onBack: () => void }) => {
  const [activeTab, setActiveTab] = useState<"marketplace" | "custom" | "orders" | "qa" | "escrow" | "talent" | "overview">("marketplace");
  const [selectedDeliverable, setSelectedDeliverable] = useState<any>(null);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/40 sticky top-0 z-40 bg-background/95 backdrop-blur">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="sm" onClick={onBack}>← Back</Button>
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-primary/60 flex items-center justify-center">
                <Rocket className="w-5 h-5 text-primary-foreground" />
              </div>
              <span className="font-bold">TalentForge</span>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="sm">
              <ShoppingCart className="h-4 w-4" />
            </Button>
            <Badge className="bg-primary/10 text-primary border-primary/20">Pro Plan</Badge>
            <Button size="sm" variant="outline">Settings</Button>
          </div>
        </div>
      </header>

      {/* Navigation Tabs */}
      <div className="border-b border-border/40 bg-background/95 backdrop-blur sticky top-16 z-30">
        <div className="container mx-auto px-4">
          <div className="flex gap-1">
            {[
              { id: "marketplace", label: "Deliverables", icon: Package },
              { id: "custom", label: "Custom Request", icon: FolderKanban },
              { id: "orders", label: "Orders", icon: ShoppingCart },
              { id: "qa", label: "Quality", icon: Award },
              { id: "escrow", label: "Escrow", icon: DollarSign },
              { id: "talent", label: "Hire Talent", icon: Users },
              { id: "overview", label: "Overview", icon: TrendingUp }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 px-4 py-3 text-sm font-medium border-b-2 transition-colors ${
                  activeTab === tab.id
                    ? "border-primary text-primary"
                    : "border-transparent text-muted-foreground hover:text-foreground"
                }`}
              >
                <tab.icon className="w-4 h-4" />
                {tab.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {activeTab === "marketplace" && (
          <DeliverableMarketplace onSelectDeliverable={setSelectedDeliverable} />
        )}
        
        {activeTab === "custom" && (
          <CustomProjectRequest />
        )}
        
        {activeTab === "orders" && <OrderTracking />}
        
        {activeTab === "qa" && <QualityAssurance />}
        
        {activeTab === "escrow" && <EscrowPayment />}
        
        {activeTab === "talent" && <TalentPool />}
        
        {activeTab === "overview" && (
          <>
            <div className="mb-8">
              <h1 className="text-3xl font-bold mb-2">Employer Dashboard</h1>
              <p className="text-muted-foreground">Manage projects, discover talent, and track outcomes</p>
            </div>

            <div className="grid lg:grid-cols-3 gap-6 mb-8">
              {[
                { label: "Active Orders", value: "12", change: "+3 this week", icon: Zap },
                { label: "Available Talent", value: "284", change: "73 in your tier", icon: Users },
                { label: "Completion Rate", value: "94%", change: "+5% vs last month", icon: TrendingUp }
              ].map((stat, i) => (
                <Card key={i} className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <stat.icon className="w-8 h-8 text-primary" />
                    <Badge variant="secondary" className="text-xs">{stat.change}</Badge>
                  </div>
                  <div className="text-3xl font-bold mb-1">{stat.value}</div>
                  <div className="text-sm text-muted-foreground">{stat.label}</div>
                </Card>
              ))}
            </div>

            <div className="grid lg:grid-cols-2 gap-6 mb-8">
              {/* Quick Actions */}
              <Card className="p-6 hover:shadow-lg transition-all cursor-pointer" onClick={() => setActiveTab("marketplace")}>
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary to-primary/60 flex items-center justify-center">
                    <Package className="w-6 h-6 text-primary-foreground" />
                  </div>
                  <div>
                    <h3 className="font-bold text-lg">Browse Deliverables</h3>
                    <p className="text-sm text-muted-foreground">Fixed-price projects ready to buy</p>
                  </div>
                </div>
                <Button className="w-full bg-gradient-to-r from-primary to-primary/80">
                  View Marketplace
                </Button>
              </Card>

              <Card className="p-6 hover:shadow-lg transition-all cursor-pointer" onClick={() => setActiveTab("custom")}>
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-accent to-accent/60 flex items-center justify-center">
                    <FolderKanban className="w-6 h-6 text-accent-foreground" />
                  </div>
                  <div>
                    <h3 className="font-bold text-lg">Custom Project</h3>
                    <p className="text-sm text-muted-foreground">Get matched with teams in 24-48h</p>
                  </div>
                </div>
                <Button variant="outline" className="w-full">
                  Create Request
                </Button>
              </Card>
            </div>

            {/* Top Candidates */}
            <Card className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold">Top Available Candidates</h2>
                <Button variant="ghost" size="sm">View All</Button>
              </div>
              <div className="space-y-3">
                {[
                  { name: "Rajesh Kumar", tier: "Lead", skills: ["React", "Node.js"], rating: 4.9 },
                  { name: "Priya Singh", tier: "Associate", skills: ["Python", "Django"], rating: 4.8 },
                  { name: "Amit Patel", tier: "Associate", skills: ["Java", "Spring"], rating: 4.7 }
                ].map((candidate, i) => (
                  <div key={i} className="flex items-center justify-between p-3 rounded-lg border border-border hover:bg-secondary/50 transition-colors">
                    <div>
                      <div className="font-semibold">{candidate.name}</div>
                      <div className="flex gap-2 mt-1">
                        {candidate.skills.map((skill, j) => (
                          <Badge key={j} variant="secondary" className="text-xs">{skill}</Badge>
                        ))}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="flex items-center gap-1 text-sm">
                        <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                        {candidate.rating}
                      </div>
                      <Badge variant="outline" className="text-xs mt-1">{candidate.tier}</Badge>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </>
        )}
      </div>

      {/* Deliverable Details Modal */}
      {selectedDeliverable && (
        <DeliverableDetails 
          deliverable={selectedDeliverable} 
          onClose={() => setSelectedDeliverable(null)} 
        />
      )}
    </div>
  );
};

export default Index;
