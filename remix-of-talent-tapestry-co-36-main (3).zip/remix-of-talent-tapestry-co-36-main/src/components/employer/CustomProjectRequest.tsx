import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { 
  Plus,
  X,
  Send,
  Sparkles
} from "lucide-react";

export const CustomProjectRequest = () => {
  const [techStack, setTechStack] = useState<string[]>([]);
  const [currentTech, setCurrentTech] = useState("");

  const addTech = () => {
    if (currentTech.trim() && !techStack.includes(currentTech.trim())) {
      setTechStack([...techStack, currentTech.trim()]);
      setCurrentTech("");
    }
  };

  const removeTech = (tech: string) => {
    setTechStack(techStack.filter(t => t !== tech));
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold mb-2">Request Custom Project</h1>
        <p className="text-muted-foreground">
          Tell us what you need and we'll match you with verified teams
        </p>
      </div>

      <Card className="p-8">
        <form className="space-y-6">
          {/* Project Type */}
          <div>
            <Label htmlFor="project-type">Project Type</Label>
            <select 
              id="project-type"
              className="w-full mt-2 px-4 py-2 border border-input rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-ring"
            >
              <option value="">Select type...</option>
              <option value="feature">Feature Development</option>
              <option value="api">API Development</option>
              <option value="frontend">Frontend Development</option>
              <option value="mobile">Mobile App Development</option>
              <option value="integration">Third-party Integration</option>
              <option value="refactoring">Code Refactoring</option>
              <option value="testing">Testing & QA</option>
            </select>
          </div>

          {/* Tech Stack */}
          <div>
            <Label htmlFor="tech-stack">Tech Stack</Label>
            <div className="flex gap-2 mt-2">
              <Input
                id="tech-stack"
                placeholder="Add technology (e.g., React, Node.js)"
                value={currentTech}
                onChange={(e) => setCurrentTech(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && (e.preventDefault(), addTech())}
              />
              <Button type="button" onClick={addTech}>
                <Plus className="h-4 w-4" />
              </Button>
            </div>
            {techStack.length > 0 && (
              <div className="flex flex-wrap gap-2 mt-3">
                {techStack.map((tech) => (
                  <Badge key={tech} variant="secondary" className="text-sm">
                    {tech}
                    <button
                      type="button"
                      onClick={() => removeTech(tech)}
                      className="ml-2 hover:text-destructive"
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </Badge>
                ))}
              </div>
            )}
          </div>

          {/* Timeline */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="timeline">Expected Timeline</Label>
              <select 
                id="timeline"
                className="w-full mt-2 px-4 py-2 border border-input rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-ring"
              >
                <option value="">Select timeline...</option>
                <option value="1-week">1 week</option>
                <option value="2-weeks">2 weeks</option>
                <option value="3-weeks">3 weeks</option>
                <option value="1-month">1 month</option>
                <option value="1-2-months">1-2 months</option>
                <option value="2-3-months">2-3 months</option>
              </select>
            </div>

            {/* Budget */}
            <div>
              <Label htmlFor="budget">Budget Range (₹)</Label>
              <select 
                id="budget"
                className="w-full mt-2 px-4 py-2 border border-input rounded-lg bg-background focus:outline-none focus:ring-2 focus:ring-ring"
              >
                <option value="">Select budget...</option>
                <option value="30-50">₹30K - ₹50K</option>
                <option value="50-80">₹50K - ₹80K</option>
                <option value="80-120">₹80K - ₹1.2L</option>
                <option value="120-200">₹1.2L - ₹2L</option>
                <option value="200-500">₹2L - ₹5L</option>
                <option value="500+">₹5L+</option>
              </select>
            </div>
          </div>

          {/* Project Title */}
          <div>
            <Label htmlFor="title">Project Title</Label>
            <Input
              id="title"
              placeholder="e.g., Build user authentication system"
              className="mt-2"
            />
          </div>

          {/* Description */}
          <div>
            <Label htmlFor="description">Project Description</Label>
            <Textarea
              id="description"
              placeholder="Describe your project requirements, goals, and any specific features you need..."
              rows={8}
              className="mt-2 resize-none"
            />
            <p className="text-xs text-muted-foreground mt-2">
              Be as specific as possible about your requirements and expected deliverables
            </p>
          </div>

          {/* Acceptance Criteria */}
          <div>
            <Label htmlFor="acceptance">Acceptance Criteria (Optional)</Label>
            <Textarea
              id="acceptance"
              placeholder="Define clear acceptance criteria and success metrics..."
              rows={4}
              className="mt-2 resize-none"
            />
          </div>

          {/* Additional Requirements */}
          <div className="grid grid-cols-2 gap-4">
            <div className="flex items-center space-x-2">
              <input type="checkbox" id="code-review" className="rounded" />
              <Label htmlFor="code-review" className="font-normal cursor-pointer">
                Include code review
              </Label>
            </div>
            <div className="flex items-center space-x-2">
              <input type="checkbox" id="documentation" className="rounded" />
              <Label htmlFor="documentation" className="font-normal cursor-pointer">
                Comprehensive documentation
              </Label>
            </div>
            <div className="flex items-center space-x-2">
              <input type="checkbox" id="testing" className="rounded" />
              <Label htmlFor="testing" className="font-normal cursor-pointer">
                Unit & integration tests
              </Label>
            </div>
            <div className="flex items-center space-x-2">
              <input type="checkbox" id="deployment" className="rounded" />
              <Label htmlFor="deployment" className="font-normal cursor-pointer">
                Deployment support
              </Label>
            </div>
          </div>

          {/* AI Suggestions */}
          <Card className="p-4 bg-primary/5 border-primary/20">
            <div className="flex items-start gap-3">
              <Sparkles className="w-5 h-5 text-primary mt-0.5" />
              <div className="flex-1">
                <h4 className="font-semibold mb-1">AI Suggestions</h4>
                <p className="text-sm text-muted-foreground mb-3">
                  Based on your description, we recommend:
                </p>
                <ul className="text-sm space-y-1 list-disc list-inside text-muted-foreground">
                  <li>Estimated timeline: 2-3 weeks</li>
                  <li>Recommended team size: 3-4 developers</li>
                  <li>Suggested budget: ₹80K - ₹1.2L</li>
                </ul>
              </div>
            </div>
          </Card>

          {/* Submit Buttons */}
          <div className="flex gap-4 pt-4">
            <Button type="button" variant="outline" className="flex-1">
              Save as Draft
            </Button>
            <Button type="submit" className="flex-1 bg-gradient-to-r from-primary to-primary/80">
              <Send className="mr-2 h-4 w-4" />
              Submit Request
            </Button>
          </div>
        </form>
      </Card>

      {/* What Happens Next */}
      <Card className="p-6 bg-secondary/30">
        <h3 className="font-bold mb-4">What happens next?</h3>
        <div className="space-y-3">
          {[
            "We'll match your project with 2-3 suitable intern teams",
            "Each team will provide a detailed proposal within 24-48 hours",
            "Review proposals, portfolios, and team performance metrics",
            "Select your preferred team and initiate escrow payment",
            "Track progress with milestone updates and automated QA reports"
          ].map((step, i) => (
            <div key={i} className="flex gap-3">
              <div className="w-6 h-6 rounded-full bg-primary/10 text-primary flex items-center justify-center text-sm font-bold flex-shrink-0">
                {i + 1}
              </div>
              <p className="text-sm text-muted-foreground">{step}</p>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
};
