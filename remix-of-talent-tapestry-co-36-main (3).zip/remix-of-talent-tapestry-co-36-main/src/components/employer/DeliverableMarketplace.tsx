import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { 
  ShoppingCart, 
  Clock, 
  DollarSign, 
  Code2, 
  Search,
  Filter,
  Star,
  CheckCircle2
} from "lucide-react";

interface Deliverable {
  id: string;
  title: string;
  price: string;
  timeline: string;
  techStack: string[];
  description: string;
  sampleProjects: number;
  rating: number;
  completionRate: number;
}

const deliverables: Deliverable[] = [
  {
    id: "1",
    title: "E-commerce Checkout Module",
    price: "₹80,000",
    timeline: "2 weeks",
    techStack: ["React", "Node.js", "Stripe", "MongoDB"],
    description: "Complete checkout flow with payment gateway integration, order management, and email notifications",
    sampleProjects: 12,
    rating: 4.8,
    completionRate: 96
  },
  {
    id: "2",
    title: "Mobile App MVP",
    price: "₹1,50,000",
    timeline: "4 weeks",
    techStack: ["React Native", "Firebase", "Redux"],
    description: "Full-featured mobile application with authentication, real-time data, and push notifications",
    sampleProjects: 8,
    rating: 4.9,
    completionRate: 94
  },
  {
    id: "3",
    title: "REST API Integration",
    price: "₹50,000",
    timeline: "10 days",
    techStack: ["Node.js", "Express", "PostgreSQL"],
    description: "Complete API layer with authentication, CRUD operations, and comprehensive documentation",
    sampleProjects: 24,
    rating: 4.7,
    completionRate: 98
  },
  {
    id: "4",
    title: "Admin Dashboard (React)",
    price: "₹1,20,000",
    timeline: "3 weeks",
    techStack: ["React", "TypeScript", "Tailwind", "Chart.js"],
    description: "Feature-rich admin panel with analytics, user management, and real-time monitoring",
    sampleProjects: 15,
    rating: 4.8,
    completionRate: 95
  },
  {
    id: "5",
    title: "Payment Gateway Integration",
    price: "₹60,000",
    timeline: "7 days",
    techStack: ["Node.js", "Razorpay", "Stripe"],
    description: "Multi-gateway payment system with webhook handling and transaction management",
    sampleProjects: 20,
    rating: 4.9,
    completionRate: 97
  },
  {
    id: "6",
    title: "200 Developer Hours",
    price: "₹1,50,000",
    timeline: "Flexible",
    techStack: ["Any Stack", "On-Demand"],
    description: "Flexible developer capacity for ongoing tasks, bug fixes, and feature development",
    sampleProjects: 30,
    rating: 4.6,
    completionRate: 92
  }
];

interface DeliverableMarketplaceProps {
  onSelectDeliverable: (deliverable: Deliverable) => void;
}

export const DeliverableMarketplace = ({ onSelectDeliverable }: DeliverableMarketplaceProps) => {
  const [searchQuery, setSearchQuery] = useState("");

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold mb-2">Ready-to-Buy Deliverables</h1>
          <p className="text-muted-foreground">Fixed-price projects delivered by verified intern teams</p>
        </div>
        <Button size="lg" className="bg-gradient-to-r from-primary to-primary/80">
          <ShoppingCart className="mr-2 h-5 w-5" />
          View Cart
        </Button>
      </div>

      {/* Search & Filters */}
      <div className="flex gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input 
            placeholder="Search deliverables..." 
            className="pl-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <Button variant="outline">
          <Filter className="mr-2 h-4 w-4" />
          Filters
        </Button>
      </div>

      {/* Deliverables Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {deliverables
          .filter(d => 
            searchQuery === "" || 
            d.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
            d.techStack.some(t => t.toLowerCase().includes(searchQuery.toLowerCase()))
          )
          .map((deliverable) => (
          <Card 
            key={deliverable.id} 
            className="p-6 hover:shadow-xl transition-all duration-300 hover:-translate-y-1 cursor-pointer"
            onClick={() => onSelectDeliverable(deliverable)}
          >
            {/* Header */}
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <h3 className="font-bold text-lg mb-1">{deliverable.title}</h3>
                <div className="flex items-center gap-1 text-sm text-muted-foreground">
                  <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                  <span className="font-semibold text-foreground">{deliverable.rating}</span>
                  <span>({deliverable.sampleProjects} delivered)</span>
                </div>
              </div>
            </div>

            {/* Price & Timeline */}
            <div className="flex items-center justify-between mb-4 pb-4 border-b">
              <div>
                <div className="text-2xl font-bold text-primary">{deliverable.price}</div>
                <div className="text-xs text-muted-foreground">Fixed price</div>
              </div>
              <div className="text-right">
                <div className="flex items-center gap-1 text-sm font-semibold">
                  <Clock className="w-4 h-4 text-muted-foreground" />
                  {deliverable.timeline}
                </div>
                <div className="text-xs text-muted-foreground">Delivery time</div>
              </div>
            </div>

            {/* Description */}
            <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
              {deliverable.description}
            </p>

            {/* Tech Stack */}
            <div className="flex flex-wrap gap-2 mb-4">
              {deliverable.techStack.slice(0, 3).map((tech, i) => (
                <Badge key={i} variant="secondary" className="text-xs">
                  <Code2 className="w-3 h-3 mr-1" />
                  {tech}
                </Badge>
              ))}
              {deliverable.techStack.length > 3 && (
                <Badge variant="secondary" className="text-xs">
                  +{deliverable.techStack.length - 3}
                </Badge>
              )}
            </div>

            {/* Completion Rate */}
            <div className="flex items-center gap-2 mb-4 text-sm">
              <CheckCircle2 className="w-4 h-4 text-success" />
              <span className="text-success font-semibold">{deliverable.completionRate}% completion rate</span>
            </div>

            {/* Actions */}
            <div className="grid grid-cols-2 gap-2">
              <Button 
                variant="outline" 
                size="sm"
                onClick={(e) => {
                  e.stopPropagation();
                  onSelectDeliverable(deliverable);
                }}
              >
                View Details
              </Button>
              <Button 
                size="sm"
                className="bg-gradient-to-r from-primary to-primary/80"
                onClick={(e) => {
                  e.stopPropagation();
                  // Add to cart logic
                }}
              >
                Buy Now
              </Button>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
};
