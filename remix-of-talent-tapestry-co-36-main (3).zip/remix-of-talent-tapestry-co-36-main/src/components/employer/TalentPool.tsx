import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import {
  Search,
  Star,
  Award,
  Briefcase,
  GraduationCap,
  CheckCircle2,
  ExternalLink,
  Filter,
  UserPlus
} from "lucide-react";

interface Candidate {
  id: string;
  name: string;
  tier: string;
  tierColor: string;
  skills: string[];
  rating: number;
  completedProjects: number;
  badges: { name: string; icon: string }[];
  availability: "available" | "busy" | "hired";
  qualityScore: number;
  placementReady: boolean;
}

const mockCandidates: Candidate[] = [
  {
    id: "1",
    name: "Rajesh Kumar",
    tier: "Lead",
    tierColor: "from-amber-400 to-amber-500",
    skills: ["React", "Node.js", "TypeScript", "PostgreSQL"],
    rating: 4.9,
    completedProjects: 18,
    badges: [
      { name: "Full Stack Pro", icon: "🏆" },
      { name: "5-Star Rated", icon: "⭐" },
      { name: "Speed Demon", icon: "⚡" }
    ],
    availability: "available",
    qualityScore: 95,
    placementReady: true
  },
  {
    id: "2",
    name: "Priya Singh",
    tier: "Associate",
    tierColor: "from-purple-400 to-purple-500",
    skills: ["Python", "Django", "AWS", "Docker"],
    rating: 4.8,
    completedProjects: 12,
    badges: [
      { name: "Backend Expert", icon: "🔧" },
      { name: "Quality Champion", icon: "🎯" }
    ],
    availability: "available",
    qualityScore: 91,
    placementReady: true
  },
  {
    id: "3",
    name: "Amit Patel",
    tier: "Associate",
    tierColor: "from-purple-400 to-purple-500",
    skills: ["Java", "Spring Boot", "Microservices"],
    rating: 4.7,
    completedProjects: 10,
    badges: [
      { name: "Reliable Deliverer", icon: "📦" },
      { name: "Team Player", icon: "🤝" }
    ],
    availability: "busy",
    qualityScore: 88,
    placementReady: false
  },
  {
    id: "4",
    name: "Sneha Reddy",
    tier: "Lead",
    tierColor: "from-amber-400 to-amber-500",
    skills: ["React Native", "Flutter", "Firebase"],
    rating: 4.9,
    completedProjects: 22,
    badges: [
      { name: "Mobile Master", icon: "📱" },
      { name: "5-Star Rated", icon: "⭐" },
      { name: "Mentor Badge", icon: "🎓" },
      { name: "Innovation Award", icon: "💡" }
    ],
    availability: "available",
    qualityScore: 97,
    placementReady: true
  },
  {
    id: "5",
    name: "Vikram Joshi",
    tier: "Contributor",
    tierColor: "from-blue-400 to-blue-500",
    skills: ["Vue.js", "Express", "MongoDB"],
    rating: 4.5,
    completedProjects: 6,
    badges: [
      { name: "Rising Star", icon: "🌟" }
    ],
    availability: "available",
    qualityScore: 82,
    placementReady: false
  }
];

export const TalentPool = () => {
  const [searchQuery, setSearchQuery] = useState("");

  const filtered = mockCandidates.filter(c =>
    searchQuery === "" ||
    c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.skills.some(s => s.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold mb-2">Hire Talent</h1>
          <p className="text-muted-foreground">Browse verified candidates with proven track records</p>
        </div>
        <Badge className="bg-primary/10 text-primary border-primary/20 text-sm px-3 py-1">
          {mockCandidates.filter(c => c.availability === "available").length} Available Now
        </Badge>
      </div>

      {/* Search */}
      <div className="flex gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search by name or skill..."
            className="pl-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <Button variant="outline">
          <Filter className="mr-2 h-4 w-4" />
          Filters
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-4">
        {[
          { label: "Total Candidates", value: "284", icon: GraduationCap },
          { label: "Placement Ready", value: "73", icon: Briefcase },
          { label: "Avg. Quality Score", value: "89%", icon: Award },
          { label: "Avg. Rating", value: "4.7", icon: Star }
        ].map((stat, i) => (
          <Card key={i} className="p-4 text-center">
            <stat.icon className="w-6 h-6 mx-auto mb-2 text-primary" />
            <div className="text-2xl font-bold">{stat.value}</div>
            <div className="text-xs text-muted-foreground">{stat.label}</div>
          </Card>
        ))}
      </div>

      {/* Candidates */}
      <div className="space-y-4">
        {filtered.map((candidate) => (
          <Card key={candidate.id} className="p-6 hover:shadow-lg transition-all duration-300">
            <div className="flex items-start gap-6">
              {/* Avatar + Tier */}
              <div className="text-center">
                <div className={`w-16 h-16 rounded-full bg-gradient-to-br ${candidate.tierColor} flex items-center justify-center text-2xl font-bold text-white mb-2`}>
                  {candidate.name.charAt(0)}
                </div>
                <Badge variant="outline" className="text-xs">{candidate.tier}</Badge>
              </div>

              {/* Info */}
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-2">
                  <h3 className="text-xl font-bold">{candidate.name}</h3>
                  <div className="flex items-center gap-1 text-sm">
                    <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                    <span className="font-semibold">{candidate.rating}</span>
                  </div>
                  {candidate.placementReady && (
                    <Badge className="bg-success/10 text-success border-success/20 text-xs">
                      <CheckCircle2 className="w-3 h-3 mr-1" />
                      Placement Ready
                    </Badge>
                  )}
                  <Badge className={
                    candidate.availability === "available"
                      ? "bg-success/10 text-success border-success/20 text-xs"
                      : candidate.availability === "busy"
                      ? "bg-amber-500/10 text-amber-500 border-amber-500/20 text-xs"
                      : "bg-muted text-muted-foreground text-xs"
                  }>
                    {candidate.availability === "available" ? "Available" :
                     candidate.availability === "busy" ? "Currently Busy" : "Hired"}
                  </Badge>
                </div>

                {/* Skills */}
                <div className="flex flex-wrap gap-2 mb-3">
                  {candidate.skills.map((skill, i) => (
                    <Badge key={i} variant="secondary" className="text-xs">{skill}</Badge>
                  ))}
                </div>

                {/* Badges */}
                <div className="flex flex-wrap gap-2 mb-3">
                  {candidate.badges.map((badge, i) => (
                    <div key={i} className="flex items-center gap-1 px-2 py-1 rounded-full bg-primary/5 border border-primary/10 text-xs">
                      <span>{badge.icon}</span>
                      <span className="font-medium">{badge.name}</span>
                    </div>
                  ))}
                </div>

                {/* Stats */}
                <div className="flex items-center gap-6 text-sm">
                  <div>
                    <span className="text-muted-foreground">Projects: </span>
                    <span className="font-semibold">{candidate.completedProjects}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-muted-foreground">Quality:</span>
                    <Progress value={candidate.qualityScore} className="w-20 h-2" />
                    <span className="font-semibold">{candidate.qualityScore}%</span>
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="flex flex-col gap-2">
                <Button size="sm" disabled={candidate.availability !== "available"}>
                  <UserPlus className="mr-1 h-4 w-4" />
                  Hire
                </Button>
                <Button size="sm" variant="outline">
                  <ExternalLink className="mr-1 h-4 w-4" />
                  Portfolio
                </Button>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
};
