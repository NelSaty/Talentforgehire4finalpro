import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import {
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Shield,
  TestTube,
  Code2,
  FileText,
  MessageSquare,
  ThumbsUp,
  ThumbsDown
} from "lucide-react";

interface QAReport {
  orderId: string;
  title: string;
  testResults: { passed: number; failed: number; skipped: number };
  codeQuality: number;
  securityScore: number;
  acceptanceChecklist: { item: string; status: "passed" | "failed" | "pending" }[];
  stewardSignOff: boolean;
  stewardName: string;
}

const mockQAReports: QAReport[] = [
  {
    orderId: "ORD-1234",
    title: "Payment Gateway Integration",
    testResults: { passed: 142, failed: 3, skipped: 5 },
    codeQuality: 92,
    securityScore: 88,
    acceptanceChecklist: [
      { item: "All API endpoints functional", status: "passed" },
      { item: "Error handling implemented", status: "passed" },
      { item: "Webhook processing verified", status: "passed" },
      { item: "Load testing completed", status: "pending" },
      { item: "Documentation reviewed", status: "passed" },
      { item: "Security audit passed", status: "failed" }
    ],
    stewardSignOff: true,
    stewardName: "Arjun Mehta"
  },
  {
    orderId: "ORD-1235",
    title: "Admin Dashboard Development",
    testResults: { passed: 89, failed: 12, skipped: 8 },
    codeQuality: 78,
    securityScore: 82,
    acceptanceChecklist: [
      { item: "CRUD operations working", status: "passed" },
      { item: "Authentication flow complete", status: "passed" },
      { item: "Role-based access control", status: "pending" },
      { item: "Responsive design verified", status: "pending" },
      { item: "Performance benchmarks met", status: "pending" },
      { item: "Accessibility standards", status: "pending" }
    ],
    stewardSignOff: false,
    stewardName: "Priya Sharma"
  }
];

export const QualityAssurance = () => {
  const getStatusIcon = (status: string) => {
    if (status === "passed") return <CheckCircle2 className="w-4 h-4 text-success" />;
    if (status === "failed") return <XCircle className="w-4 h-4 text-destructive" />;
    return <AlertTriangle className="w-4 h-4 text-amber-500" />;
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">Quality Assurance</h1>
        <p className="text-muted-foreground">Automated test results, code quality, and acceptance status</p>
      </div>

      <div className="space-y-6">
        {mockQAReports.map((report) => {
          const totalTests = report.testResults.passed + report.testResults.failed + report.testResults.skipped;
          const passRate = Math.round((report.testResults.passed / totalTests) * 100);

          return (
            <Card key={report.orderId} className="p-6">
              {/* Header */}
              <div className="flex items-start justify-between mb-6">
                <div>
                  <div className="flex items-center gap-3 mb-1">
                    <h2 className="text-2xl font-bold">{report.title}</h2>
                    <Badge variant="outline" className="text-xs">{report.orderId}</Badge>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Steward: {report.stewardName} •{" "}
                    {report.stewardSignOff ? (
                      <span className="text-success font-semibold">✓ Signed Off</span>
                    ) : (
                      <span className="text-amber-500 font-semibold">⏳ Pending Sign-off</span>
                    )}
                  </p>
                </div>
                {report.stewardSignOff && (
                  <Badge className="bg-success/10 text-success border-success/20">
                    <Shield className="w-3 h-3 mr-1" />
                    Steward Approved
                  </Badge>
                )}
              </div>

              <div className="grid lg:grid-cols-3 gap-6 mb-6">
                {/* Test Results */}
                <Card className="p-4 bg-secondary/30">
                  <div className="flex items-center gap-2 mb-3">
                    <TestTube className="w-5 h-5 text-primary" />
                    <h3 className="font-bold">Test Results</h3>
                  </div>
                  <div className="text-3xl font-bold mb-2">{passRate}%</div>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-success">Passed</span>
                      <span className="font-semibold">{report.testResults.passed}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-destructive">Failed</span>
                      <span className="font-semibold">{report.testResults.failed}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Skipped</span>
                      <span className="font-semibold">{report.testResults.skipped}</span>
                    </div>
                  </div>
                </Card>

                {/* Code Quality */}
                <Card className="p-4 bg-secondary/30">
                  <div className="flex items-center gap-2 mb-3">
                    <Code2 className="w-5 h-5 text-primary" />
                    <h3 className="font-bold">Code Quality</h3>
                  </div>
                  <div className="text-3xl font-bold mb-2">{report.codeQuality}/100</div>
                  <Progress value={report.codeQuality} className="h-2 mb-2" />
                  <p className="text-xs text-muted-foreground">
                    {report.codeQuality >= 90 ? "Excellent" : report.codeQuality >= 80 ? "Good" : "Needs improvement"}
                  </p>
                </Card>

                {/* Security Score */}
                <Card className="p-4 bg-secondary/30">
                  <div className="flex items-center gap-2 mb-3">
                    <Shield className="w-5 h-5 text-primary" />
                    <h3 className="font-bold">Security Score</h3>
                  </div>
                  <div className="text-3xl font-bold mb-2">{report.securityScore}/100</div>
                  <Progress value={report.securityScore} className="h-2 mb-2" />
                  <p className="text-xs text-muted-foreground">
                    {report.securityScore >= 90 ? "Secure" : report.securityScore >= 80 ? "Acceptable" : "Review needed"}
                  </p>
                </Card>
              </div>

              {/* Acceptance Checklist */}
              <div className="mb-6">
                <h3 className="font-bold mb-3 flex items-center gap-2">
                  <FileText className="w-5 h-5" />
                  Acceptance Checklist
                </h3>
                <div className="grid md:grid-cols-2 gap-2">
                  {report.acceptanceChecklist.map((item, i) => (
                    <div key={i} className="flex items-center gap-3 p-3 rounded-lg border border-border">
                      {getStatusIcon(item.status)}
                      <span className="text-sm">{item.item}</span>
                      <Badge variant="secondary" className="ml-auto text-xs capitalize">{item.status}</Badge>
                    </div>
                  ))}
                </div>
              </div>

              {/* Client Feedback */}
              <div className="border-t pt-6">
                <h3 className="font-bold mb-3 flex items-center gap-2">
                  <MessageSquare className="w-5 h-5" />
                  Your Feedback
                </h3>
                <div className="flex gap-3">
                  <Button variant="outline" className="flex-1">
                    <ThumbsDown className="mr-2 h-4 w-4" />
                    Request Revisions
                  </Button>
                  <Button className="flex-1 bg-gradient-to-r from-success to-success/80">
                    <ThumbsUp className="mr-2 h-4 w-4" />
                    Approve & Accept
                  </Button>
                </div>
              </div>
            </Card>
          );
        })}
      </div>
    </div>
  );
};
