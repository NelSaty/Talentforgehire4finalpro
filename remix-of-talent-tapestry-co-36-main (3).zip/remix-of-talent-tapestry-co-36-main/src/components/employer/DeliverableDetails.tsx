import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  X,
  Clock,
  DollarSign,
  CheckCircle2,
  Shield,
  FileCode,
  GitBranch,
  TestTube,
  FileText,
  Star,
  TrendingUp
} from "lucide-react";

interface DeliverableDetailsProps {
  deliverable: {
    id: string;
    title: string;
    price: string;
    timeline: string;
    techStack: string[];
    description: string;
    sampleProjects: number;
    rating: number;
    completionRate: number;
  };
  onClose: () => void;
}

export const DeliverableDetails = ({ deliverable, onClose }: DeliverableDetailsProps) => {
  return (
    <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-start justify-center overflow-y-auto p-4">
      <div className="w-full max-w-4xl my-8">
        <Card className="p-8">
          {/* Header */}
          <div className="flex items-start justify-between mb-6">
            <div className="flex-1">
              <h1 className="text-3xl font-bold mb-2">{deliverable.title}</h1>
              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                <div className="flex items-center gap-1">
                  <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                  <span className="font-semibold text-foreground">{deliverable.rating}</span>
                  <span>({deliverable.sampleProjects} delivered)</span>
                </div>
                <span>•</span>
                <div className="flex items-center gap-1 text-success">
                  <TrendingUp className="w-4 h-4" />
                  <span className="font-semibold">{deliverable.completionRate}% success rate</span>
                </div>
              </div>
            </div>
            <Button variant="ghost" size="icon" onClick={onClose}>
              <X className="h-5 w-5" />
            </Button>
          </div>

          {/* Price & Timeline */}
          <div className="grid md:grid-cols-2 gap-4 mb-8">
            <Card className="p-6 bg-primary/5 border-primary/20">
              <div className="flex items-center gap-3 mb-2">
                <DollarSign className="w-5 h-5 text-primary" />
                <span className="text-sm font-medium text-muted-foreground">Fixed Price</span>
              </div>
              <div className="text-3xl font-bold text-primary">{deliverable.price}</div>
              <p className="text-xs text-muted-foreground mt-1">Includes all deliverables</p>
            </Card>
            <Card className="p-6 bg-secondary/50">
              <div className="flex items-center gap-3 mb-2">
                <Clock className="w-5 h-5 text-foreground" />
                <span className="text-sm font-medium text-muted-foreground">Delivery Time</span>
              </div>
              <div className="text-3xl font-bold">{deliverable.timeline}</div>
              <p className="text-xs text-muted-foreground mt-1">From project start</p>
            </Card>
          </div>

          {/* Description */}
          <div className="mb-8">
            <h2 className="text-xl font-bold mb-3">What's Included</h2>
            <p className="text-muted-foreground mb-4">{deliverable.description}</p>
            <ul className="space-y-2">
              {[
                "Complete source code with documentation",
                "Comprehensive unit and integration tests",
                "API documentation and usage guides",
                "Deployment instructions and support",
                "Code review and quality assurance",
                "2 weeks of post-delivery support"
              ].map((item, i) => (
                <li key={i} className="flex items-start gap-2">
                  <CheckCircle2 className="w-5 h-5 text-success flex-shrink-0 mt-0.5" />
                  <span className="text-sm">{item}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Tech Stack */}
          <div className="mb-8">
            <h2 className="text-xl font-bold mb-3">Technology Stack</h2>
            <div className="flex flex-wrap gap-2">
              {deliverable.techStack.map((tech, i) => (
                <Badge key={i} variant="secondary" className="text-sm px-3 py-1">
                  {tech}
                </Badge>
              ))}
            </div>
          </div>

          {/* Sample Deliverables */}
          <div className="mb-8">
            <h2 className="text-xl font-bold mb-3">Sample Deliverables</h2>
            <div className="grid md:grid-cols-2 gap-4">
              {[
                { icon: FileCode, name: "Clean, documented code", desc: "Production-ready with best practices" },
                { icon: TestTube, name: "Comprehensive tests", desc: "90%+ code coverage guaranteed" },
                { icon: FileText, name: "Documentation", desc: "API docs and user guides" },
                { icon: GitBranch, name: "Version control", desc: "Complete Git history included" }
              ].map((item, i) => (
                <Card key={i} className="p-4 hover:shadow-lg transition-all">
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <item.icon className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <div className="font-semibold mb-1">{item.name}</div>
                      <div className="text-xs text-muted-foreground">{item.desc}</div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>

          {/* Acceptance Criteria */}
          <div className="mb-8">
            <h2 className="text-xl font-bold mb-3">Acceptance Criteria</h2>
            <Card className="p-4 bg-secondary/30">
              <ul className="space-y-2 text-sm">
                <li className="flex items-start gap-2">
                  <span className="font-bold text-primary">✓</span>
                  <span>All features from the specification document are implemented and working</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="font-bold text-primary">✓</span>
                  <span>Code passes all automated quality checks and security scans</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="font-bold text-primary">✓</span>
                  <span>Test coverage is at least 90% with all tests passing</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="font-bold text-primary">✓</span>
                  <span>Documentation is complete and accurate</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="font-bold text-primary">✓</span>
                  <span>Code review approved by senior developer</span>
                </li>
              </ul>
            </Card>
          </div>

          {/* Escrow & IP Terms */}
          <div className="mb-8">
            <h2 className="text-xl font-bold mb-3">Payment & IP Terms</h2>
            <Card className="p-6 bg-secondary/30">
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <Shield className="w-5 h-5 text-success flex-shrink-0 mt-1" />
                  <div>
                    <div className="font-semibold mb-1">Escrow Protection</div>
                    <p className="text-sm text-muted-foreground">
                      Payment is held in secure escrow and only released when you accept the deliverables
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Shield className="w-5 h-5 text-success flex-shrink-0 mt-1" />
                  <div>
                    <div className="font-semibold mb-1">Full IP Transfer</div>
                    <p className="text-sm text-muted-foreground">
                      You own all intellectual property rights to the delivered code and documentation
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Shield className="w-5 h-5 text-success flex-shrink-0 mt-1" />
                  <div>
                    <div className="font-semibold mb-1">Quality Guarantee</div>
                    <p className="text-sm text-muted-foreground">
                      Free revisions if deliverables don't meet acceptance criteria
                    </p>
                  </div>
                </div>
              </div>
            </Card>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-4">
            <Button 
              variant="outline" 
              className="flex-1"
              onClick={onClose}
            >
              Close
            </Button>
            <Button 
              className="flex-1 bg-gradient-to-r from-primary to-primary/80 text-lg py-6"
            >
              Add to Cart - {deliverable.price}
            </Button>
          </div>
        </Card>
      </div>
    </div>
  );
};
