import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Shield,
  Lock,
  CheckCircle2,
  Clock,
  ArrowRight,
  CreditCard,
  Building2,
  FileText,
  AlertCircle
} from "lucide-react";

interface EscrowOrder {
  id: string;
  title: string;
  amount: string;
  status: "pending" | "funded" | "milestone_released" | "completed" | "disputed";
  milestones: { name: string; amount: string; status: "released" | "locked" | "pending" }[];
  createdAt: string;
}

const mockEscrowOrders: EscrowOrder[] = [
  {
    id: "ESC-001",
    title: "Payment Gateway Integration",
    amount: "₹60,000",
    status: "milestone_released",
    milestones: [
      { name: "Requirements & Setup", amount: "₹15,000", status: "released" },
      { name: "Core Development", amount: "₹25,000", status: "released" },
      { name: "Testing & QA", amount: "₹10,000", status: "locked" },
      { name: "Final Delivery", amount: "₹10,000", status: "pending" }
    ],
    createdAt: "Jan 10, 2025"
  },
  {
    id: "ESC-002",
    title: "Admin Dashboard Development",
    amount: "₹1,20,000",
    status: "funded",
    milestones: [
      { name: "UI/UX Design", amount: "₹20,000", status: "locked" },
      { name: "Frontend Development", amount: "₹40,000", status: "pending" },
      { name: "Backend Integration", amount: "₹35,000", status: "pending" },
      { name: "Testing & Deployment", amount: "₹25,000", status: "pending" }
    ],
    createdAt: "Jan 18, 2025"
  }
];

const escrowSteps = [
  { icon: CreditCard, label: "Fund Escrow", desc: "Secure payment held safely" },
  { icon: Building2, label: "Team Works", desc: "Development with milestones" },
  { icon: CheckCircle2, label: "Accept Delivery", desc: "Review and approve work" },
  { icon: Lock, label: "Payment Released", desc: "Funds released to team" }
];

export const EscrowPayment = () => {
  const getMilestoneColor = (status: string) => {
    if (status === "released") return "bg-success/10 text-success border-success/20";
    if (status === "locked") return "bg-primary/10 text-primary border-primary/20";
    return "bg-muted text-muted-foreground";
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">Escrow Payments</h1>
        <p className="text-muted-foreground">Secure milestone-based payments with full protection</p>
      </div>

      {/* How Escrow Works */}
      <Card className="p-6 bg-gradient-to-r from-primary/5 to-accent/5 border-primary/20">
        <h2 className="font-bold text-lg mb-4 flex items-center gap-2">
          <Shield className="w-5 h-5 text-primary" />
          How Escrow Works
        </h2>
        <div className="grid grid-cols-4 gap-4">
          {escrowSteps.map((step, i) => (
            <div key={i} className="text-center relative">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-2">
                <step.icon className="w-6 h-6 text-primary" />
              </div>
              <div className="text-sm font-semibold">{step.label}</div>
              <div className="text-xs text-muted-foreground">{step.desc}</div>
              {i < escrowSteps.length - 1 && (
                <ArrowRight className="w-4 h-4 text-muted-foreground absolute top-4 -right-2 hidden md:block" />
              )}
            </div>
          ))}
        </div>
      </Card>

      {/* Escrow Orders */}
      <div className="space-y-6">
        {mockEscrowOrders.map((order) => (
          <Card key={order.id} className="p-6">
            <div className="flex items-start justify-between mb-6">
              <div>
                <div className="flex items-center gap-3 mb-1">
                  <h2 className="text-xl font-bold">{order.title}</h2>
                  <Badge variant="outline" className="text-xs">{order.id}</Badge>
                </div>
                <p className="text-sm text-muted-foreground">
                  Created: {order.createdAt} • Total: <span className="font-semibold text-foreground">{order.amount}</span>
                </p>
              </div>
              <Badge className={
                order.status === "funded" ? "bg-primary/10 text-primary border-primary/20" :
                order.status === "milestone_released" ? "bg-success/10 text-success border-success/20" :
                "bg-muted text-muted-foreground"
              }>
                <Lock className="w-3 h-3 mr-1" />
                {order.status === "funded" ? "Escrow Funded" :
                 order.status === "milestone_released" ? "Milestones Active" :
                 "Completed"}
              </Badge>
            </div>

            {/* Milestones */}
            <div className="space-y-3">
              {order.milestones.map((milestone, i) => (
                <div key={i} className="flex items-center justify-between p-4 rounded-lg border border-border">
                  <div className="flex items-center gap-3">
                    {milestone.status === "released" ? (
                      <CheckCircle2 className="w-5 h-5 text-success" />
                    ) : milestone.status === "locked" ? (
                      <Lock className="w-5 h-5 text-primary" />
                    ) : (
                      <Clock className="w-5 h-5 text-muted-foreground" />
                    )}
                    <div>
                      <div className="font-medium text-sm">{milestone.name}</div>
                      <div className="text-xs text-muted-foreground">{milestone.amount}</div>
                    </div>
                  </div>
                  <Badge className={getMilestoneColor(milestone.status)}>
                    {milestone.status === "released" ? "Released" :
                     milestone.status === "locked" ? "In Escrow" : "Pending"}
                  </Badge>
                </div>
              ))}
            </div>

            {/* Actions */}
            <div className="flex gap-3 mt-6 pt-6 border-t">
              <Button variant="outline" className="flex-1">
                <FileText className="mr-2 h-4 w-4" />
                View Contract
              </Button>
              <Button variant="outline" className="flex-1">
                <AlertCircle className="mr-2 h-4 w-4" />
                Raise Dispute
              </Button>
              <Button className="flex-1 bg-gradient-to-r from-success to-success/80">
                <CheckCircle2 className="mr-2 h-4 w-4" />
                Release Next Milestone
              </Button>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
};
