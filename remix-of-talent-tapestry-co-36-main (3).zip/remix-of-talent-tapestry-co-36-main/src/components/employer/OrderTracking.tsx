import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  CheckCircle2, 
  Circle, 
  Clock,
  AlertCircle,
  MessageSquare,
  Download,
  FileCode,
  FileText,
  GitBranch,
  TestTube
} from "lucide-react";

interface Order {
  id: string;
  title: string;
  status: "requirements" | "development" | "testing" | "review" | "delivered" | "accepted";
  progress: number;
  teamSize: number;
  deadline: string;
  price: string;
  milestones: {
    name: string;
    status: "completed" | "in-progress" | "pending";
    date?: string;
  }[];
  deliverables: {
    name: string;
    type: "code" | "docs" | "tests" | "other";
    status: "ready" | "pending";
    url?: string;
  }[];
  metrics: {
    codeQuality: number;
    testCoverage: number;
    commits: number;
  };
}

const mockOrders: Order[] = [
  {
    id: "ORD-1234",
    title: "Payment Gateway Integration",
    status: "testing",
    progress: 80,
    teamSize: 3,
    deadline: "2 days remaining",
    price: "₹60,000",
    milestones: [
      { name: "Requirements gathered", status: "completed", date: "Jan 15" },
      { name: "Development complete", status: "completed", date: "Jan 22" },
      { name: "Testing in progress", status: "in-progress" },
      { name: "Acceptance pending", status: "pending" }
    ],
    deliverables: [
      { name: "Source code", type: "code", status: "ready", url: "#" },
      { name: "API documentation", type: "docs", status: "ready", url: "#" },
      { name: "Test reports", type: "tests", status: "ready", url: "#" },
      { name: "Deployment guide", type: "docs", status: "pending" }
    ],
    metrics: {
      codeQuality: 92,
      testCoverage: 94,
      commits: 127
    }
  },
  {
    id: "ORD-1235",
    title: "Admin Dashboard Development",
    status: "development",
    progress: 45,
    teamSize: 4,
    deadline: "8 days remaining",
    price: "₹1,20,000",
    milestones: [
      { name: "Requirements gathered", status: "completed", date: "Jan 10" },
      { name: "Development in progress", status: "in-progress" },
      { name: "Testing pending", status: "pending" },
      { name: "Delivery pending", status: "pending" }
    ],
    deliverables: [
      { name: "Source code", type: "code", status: "pending" },
      { name: "Documentation", type: "docs", status: "pending" },
      { name: "Test suite", type: "tests", status: "pending" }
    ],
    metrics: {
      codeQuality: 88,
      testCoverage: 76,
      commits: 89
    }
  }
];

export const OrderTracking = () => {
  const getStatusIcon = (status: string) => {
    if (status === "completed") return <CheckCircle2 className="w-5 h-5 text-success" />;
    if (status === "in-progress") return <Clock className="w-5 h-5 text-primary animate-pulse" />;
    return <Circle className="w-5 h-5 text-muted-foreground" />;
  };

  const getDeliverableIcon = (type: string) => {
    switch (type) {
      case "code": return <FileCode className="w-4 h-4" />;
      case "docs": return <FileText className="w-4 h-4" />;
      case "tests": return <TestTube className="w-4 h-4" />;
      default: return <GitBranch className="w-4 h-4" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold mb-2">Active Orders</h1>
        <p className="text-muted-foreground">Track your projects and review deliverables</p>
      </div>

      {/* Orders */}
      <div className="space-y-6">
        {mockOrders.map((order) => (
          <Card key={order.id} className="p-6">
            {/* Order Header */}
            <div className="flex items-start justify-between mb-6">
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-2">
                  <h2 className="text-2xl font-bold">{order.title}</h2>
                  <Badge variant="outline" className="text-xs">
                    {order.id}
                  </Badge>
                </div>
                <div className="flex items-center gap-4 text-sm text-muted-foreground">
                  <span>{order.teamSize} developers assigned</span>
                  <span>•</span>
                  <span className="flex items-center gap-1">
                    <Clock className="w-4 h-4" />
                    {order.deadline}
                  </span>
                  <span>•</span>
                  <span className="font-semibold text-foreground">{order.price}</span>
                </div>
              </div>
              <Button variant="outline">
                <MessageSquare className="mr-2 h-4 w-4" />
                Message Team
              </Button>
            </div>

            {/* Progress Bar */}
            <div className="mb-6">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-semibold">Overall Progress</span>
                <span className="text-sm font-bold text-primary">{order.progress}%</span>
              </div>
              <Progress value={order.progress} className="h-2" />
            </div>

            <div className="grid lg:grid-cols-2 gap-6">
              {/* Milestones */}
              <div>
                <h3 className="font-bold mb-4">Milestones</h3>
                <div className="space-y-3">
                  {order.milestones.map((milestone, i) => (
                    <div key={i} className="flex items-start gap-3">
                      {getStatusIcon(milestone.status)}
                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <span className={`text-sm font-medium ${
                            milestone.status === "completed" 
                              ? "text-success" 
                              : milestone.status === "in-progress"
                              ? "text-primary"
                              : "text-muted-foreground"
                          }`}>
                            {milestone.name}
                          </span>
                          {milestone.date && (
                            <span className="text-xs text-muted-foreground">{milestone.date}</span>
                          )}
                        </div>
                        {milestone.status === "in-progress" && (
                          <div className="mt-2">
                            <Progress value={65} className="h-1" />
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Deliverables */}
              <div>
                <h3 className="font-bold mb-4">Deliverables</h3>
                <div className="space-y-2">
                  {order.deliverables.map((deliverable, i) => (
                    <div 
                      key={i} 
                      className="flex items-center justify-between p-3 rounded-lg border border-border hover:bg-secondary/50 transition-colors"
                    >
                      <div className="flex items-center gap-3">
                        {getDeliverableIcon(deliverable.type)}
                        <span className="text-sm font-medium">{deliverable.name}</span>
                      </div>
                      {deliverable.status === "ready" ? (
                        <Button size="sm" variant="outline">
                          <Download className="mr-1 h-3 w-3" />
                          Download
                        </Button>
                      ) : (
                        <Badge variant="secondary" className="text-xs">
                          Pending
                        </Badge>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Quality Metrics */}
            <div className="mt-6 pt-6 border-t">
              <h3 className="font-bold mb-4">Quality Metrics</h3>
              <div className="grid grid-cols-3 gap-6">
                <div>
                  <div className="text-sm text-muted-foreground mb-2">Code Quality</div>
                  <div className="flex items-center gap-2">
                    <Progress value={order.metrics.codeQuality} className="flex-1 h-2" />
                    <span className="text-sm font-bold">{order.metrics.codeQuality}%</span>
                  </div>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground mb-2">Test Coverage</div>
                  <div className="flex items-center gap-2">
                    <Progress value={order.metrics.testCoverage} className="flex-1 h-2" />
                    <span className="text-sm font-bold">{order.metrics.testCoverage}%</span>
                  </div>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground mb-2">Git Commits</div>
                  <div className="flex items-center gap-2">
                    <GitBranch className="w-4 h-4 text-muted-foreground" />
                    <span className="text-sm font-bold">{order.metrics.commits}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Actions */}
            {order.status === "testing" && (
              <div className="mt-6 pt-6 border-t flex gap-3">
                <Button variant="outline" className="flex-1">
                  <AlertCircle className="mr-2 h-4 w-4" />
                  Request Changes
                </Button>
                <Button className="flex-1 bg-gradient-to-r from-success to-success/80">
                  <CheckCircle2 className="mr-2 h-4 w-4" />
                  Accept Delivery
                </Button>
              </div>
            )}
          </Card>
        ))}
      </div>
    </div>
  );
};
