import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import {
  BookOpen,
  CheckCircle2,
  Clock,
  Play,
  Lock,
  Star,
  ArrowRight,
  GraduationCap,
  Code2,
  TestTube,
  Shield,
  Users
} from "lucide-react";

interface Module {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  duration: string;
  lessons: number;
  completedLessons: number;
  status: "completed" | "in-progress" | "locked";
  skills: string[];
}

const trainingModules: Module[] = [
  {
    id: "1",
    title: "Onboarding & Assessment",
    description: "Introduction to the platform, skill assessment, and tier placement",
    icon: <GraduationCap className="w-6 h-6" />,
    duration: "2 days",
    lessons: 5,
    completedLessons: 5,
    status: "completed",
    skills: ["Platform Usage", "Self-Assessment"]
  },
  {
    id: "2",
    title: "Code Quality & Best Practices",
    description: "Clean code principles, design patterns, and code review processes",
    icon: <Code2 className="w-6 h-6" />,
    duration: "1 week",
    lessons: 8,
    completedLessons: 8,
    status: "completed",
    skills: ["Clean Code", "Design Patterns", "Code Review"]
  },
  {
    id: "3",
    title: "Testing & Quality Assurance",
    description: "Unit testing, integration testing, TDD, and quality metrics",
    icon: <TestTube className="w-6 h-6" />,
    duration: "1 week",
    lessons: 7,
    completedLessons: 5,
    status: "in-progress",
    skills: ["Unit Testing", "Integration Testing", "TDD"]
  },
  {
    id: "4",
    title: "Security Fundamentals",
    description: "OWASP top 10, secure coding, authentication & authorization",
    icon: <Shield className="w-6 h-6" />,
    duration: "1 week",
    lessons: 6,
    completedLessons: 0,
    status: "locked",
    skills: ["OWASP", "Secure Coding", "Auth Systems"]
  },
  {
    id: "5",
    title: "Team Collaboration & Communication",
    description: "Agile workflows, Git collaboration, documentation, and client communication",
    icon: <Users className="w-6 h-6" />,
    duration: "5 days",
    lessons: 6,
    completedLessons: 0,
    status: "locked",
    skills: ["Agile", "Git Workflow", "Documentation"]
  },
  {
    id: "6",
    title: "Project Delivery & Deployment",
    description: "CI/CD pipelines, deployment strategies, monitoring, and handoff processes",
    icon: <BookOpen className="w-6 h-6" />,
    duration: "1 week",
    lessons: 7,
    completedLessons: 0,
    status: "locked",
    skills: ["CI/CD", "Docker", "Monitoring"]
  }
];

const methodology = [
  { step: "1", title: "Assess", desc: "Standardized skill evaluation determines starting tier and learning path" },
  { step: "2", title: "Train", desc: "Structured modules covering technical and soft skills with hands-on projects" },
  { step: "3", title: "Practice", desc: "Supervised micro-sprints on real company projects with mentor guidance" },
  { step: "4", title: "Evaluate", desc: "Automated quality checks, peer reviews, and steward assessments" },
  { step: "5", title: "Progress", desc: "Performance-based tier advancement unlocking higher-value projects" },
  { step: "6", title: "Place", desc: "Top performers fast-tracked to full-time positions with partner companies" }
];

export const TrainingMethodology = () => {
  const totalLessons = trainingModules.reduce((sum, m) => sum + m.lessons, 0);
  const completedLessons = trainingModules.reduce((sum, m) => sum + m.completedLessons, 0);
  const overallProgress = Math.round((completedLessons / totalLessons) * 100);

  return (
    <div className="space-y-6">
      {/* Overall Progress */}
      <Card className="p-6 bg-gradient-to-r from-primary/5 to-accent/5 border-primary/20">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h2 className="text-xl font-bold">Training Progress</h2>
            <p className="text-sm text-muted-foreground">{completedLessons} of {totalLessons} lessons completed</p>
          </div>
          <div className="text-3xl font-bold text-primary">{overallProgress}%</div>
        </div>
        <Progress value={overallProgress} className="h-3" />
      </Card>

      {/* Methodology Overview */}
      <Card className="p-6">
        <h2 className="text-lg font-bold mb-4 flex items-center gap-2">
          <BookOpen className="w-5 h-5 text-primary" />
          Our Methodology
        </h2>
        <div className="grid grid-cols-6 gap-3">
          {methodology.map((item, i) => (
            <div key={i} className="text-center">
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-2 text-primary font-bold text-sm">
                {item.step}
              </div>
              <div className="text-sm font-semibold mb-1">{item.title}</div>
              <p className="text-xs text-muted-foreground">{item.desc}</p>
            </div>
          ))}
        </div>
      </Card>

      {/* Training Modules */}
      <div>
        <h2 className="text-xl font-bold mb-4">Training Modules</h2>
        <div className="space-y-4">
          {trainingModules.map((module) => {
            const moduleProgress = module.lessons > 0
              ? Math.round((module.completedLessons / module.lessons) * 100)
              : 0;

            return (
              <Card key={module.id} className={`p-6 ${module.status === "locked" ? "opacity-60" : ""}`}>
                <div className="flex items-start gap-4">
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 ${
                    module.status === "completed"
                      ? "bg-success/10 text-success"
                      : module.status === "in-progress"
                      ? "bg-primary/10 text-primary"
                      : "bg-muted text-muted-foreground"
                  }`}>
                    {module.icon}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-1">
                      <h3 className="font-bold text-lg">{module.title}</h3>
                      {module.status === "completed" && (
                        <Badge className="bg-success/10 text-success border-success/20 text-xs">
                          <CheckCircle2 className="w-3 h-3 mr-1" /> Completed
                        </Badge>
                      )}
                      {module.status === "in-progress" && (
                        <Badge className="bg-primary/10 text-primary border-primary/20 text-xs">
                          <Play className="w-3 h-3 mr-1" /> In Progress
                        </Badge>
                      )}
                      {module.status === "locked" && (
                        <Badge variant="secondary" className="text-xs">
                          <Lock className="w-3 h-3 mr-1" /> Locked
                        </Badge>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground mb-2">{module.description}</p>
                    <div className="flex flex-wrap gap-2 mb-3">
                      {module.skills.map((skill, i) => (
                        <Badge key={i} variant="secondary" className="text-xs">{skill}</Badge>
                      ))}
                    </div>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground mb-2">
                      <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {module.duration}</span>
                      <span>{module.completedLessons}/{module.lessons} lessons</span>
                    </div>
                    {module.status !== "locked" && (
                      <Progress value={moduleProgress} className="h-2" />
                    )}
                  </div>
                  {module.status === "in-progress" && (
                    <Button size="sm">
                      Continue
                      <ArrowRight className="ml-1 h-4 w-4" />
                    </Button>
                  )}
                </div>
              </Card>
            );
          })}
        </div>
      </div>
    </div>
  );
};
