import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import {
  CheckCircle2,
  XCircle,
  Clock,
  Code2,
  Brain,
  MessageSquare,
  BarChart3,
  Trophy,
  Target,
  ArrowRight
} from "lucide-react";

interface AssessmentResult {
  id: string;
  name: string;
  category: string;
  score: number;
  maxScore: number;
  status: "passed" | "failed" | "pending";
  date: string;
  details: { section: string; score: number; max: number }[];
}

const mockAssessments: AssessmentResult[] = [
  {
    id: "1",
    name: "JavaScript Fundamentals",
    category: "Frontend",
    score: 87,
    maxScore: 100,
    status: "passed",
    date: "Dec 15, 2024",
    details: [
      { section: "Variables & Types", score: 18, max: 20 },
      { section: "Functions & Closures", score: 16, max: 20 },
      { section: "Async Programming", score: 19, max: 20 },
      { section: "DOM Manipulation", score: 17, max: 20 },
      { section: "Error Handling", score: 17, max: 20 }
    ]
  },
  {
    id: "2",
    name: "React & Component Architecture",
    category: "Frontend",
    score: 92,
    maxScore: 100,
    status: "passed",
    date: "Dec 22, 2024",
    details: [
      { section: "Component Design", score: 19, max: 20 },
      { section: "State Management", score: 18, max: 20 },
      { section: "Hooks & Lifecycle", score: 19, max: 20 },
      { section: "Performance", score: 18, max: 20 },
      { section: "Testing", score: 18, max: 20 }
    ]
  },
  {
    id: "3",
    name: "Node.js Backend Development",
    category: "Backend",
    score: 78,
    maxScore: 100,
    status: "passed",
    date: "Jan 5, 2025",
    details: [
      { section: "API Design", score: 17, max: 20 },
      { section: "Database Integration", score: 14, max: 20 },
      { section: "Authentication", score: 16, max: 20 },
      { section: "Error Handling", score: 15, max: 20 },
      { section: "Security", score: 16, max: 20 }
    ]
  },
  {
    id: "4",
    name: "System Design Basics",
    category: "Architecture",
    score: 0,
    maxScore: 100,
    status: "pending",
    date: "Scheduled",
    details: []
  },
  {
    id: "5",
    name: "Data Structures & Algorithms",
    category: "Core CS",
    score: 65,
    maxScore: 100,
    status: "failed",
    date: "Jan 12, 2025",
    details: [
      { section: "Arrays & Strings", score: 16, max: 20 },
      { section: "Trees & Graphs", score: 10, max: 20 },
      { section: "Dynamic Programming", score: 8, max: 20 },
      { section: "Sorting & Searching", score: 15, max: 20 },
      { section: "Time Complexity", score: 16, max: 20 }
    ]
  }
];

const skillRadar = [
  { skill: "Frontend", level: 88 },
  { skill: "Backend", level: 72 },
  { skill: "Database", level: 65 },
  { skill: "DevOps", level: 45 },
  { skill: "Testing", level: 78 },
  { skill: "Communication", level: 82 }
];

export const AssessmentScores = () => {
  const passed = mockAssessments.filter(a => a.status === "passed").length;
  const avgScore = Math.round(
    mockAssessments.filter(a => a.status !== "pending").reduce((sum, a) => sum + a.score, 0) /
    mockAssessments.filter(a => a.status !== "pending").length
  );

  return (
    <div className="space-y-6">
      {/* Overview */}
      <div className="grid grid-cols-4 gap-4">
        {[
          { label: "Assessments Taken", value: "4", icon: Brain, color: "text-primary" },
          { label: "Passed", value: `${passed}`, icon: CheckCircle2, color: "text-success" },
          { label: "Average Score", value: `${avgScore}%`, icon: BarChart3, color: "text-primary" },
          { label: "Current Tier", value: "Contributor", icon: Trophy, color: "text-amber-500" }
        ].map((stat, i) => (
          <Card key={i} className="p-4 text-center">
            <stat.icon className={`w-6 h-6 mx-auto mb-2 ${stat.color}`} />
            <div className="text-2xl font-bold">{stat.value}</div>
            <div className="text-xs text-muted-foreground">{stat.label}</div>
          </Card>
        ))}
      </div>

      {/* Skill Levels */}
      <Card className="p-6">
        <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
          <Target className="w-5 h-5 text-primary" />
          Skill Levels
        </h2>
        <div className="grid grid-cols-2 gap-4">
          {skillRadar.map((item, i) => (
            <div key={i} className="flex items-center gap-3">
              <span className="text-sm font-medium w-28">{item.skill}</span>
              <Progress value={item.level} className="flex-1 h-2" />
              <span className="text-sm font-bold w-10 text-right">{item.level}%</span>
            </div>
          ))}
        </div>
      </Card>

      {/* Assessment Results */}
      <div>
        <h2 className="text-xl font-bold mb-4">Assessment Results</h2>
        <div className="space-y-4">
          {mockAssessments.map((assessment) => (
            <Card key={assessment.id} className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <div className="flex items-center gap-3 mb-1">
                    <h3 className="text-lg font-bold">{assessment.name}</h3>
                    <Badge variant="outline" className="text-xs">{assessment.category}</Badge>
                  </div>
                  <p className="text-sm text-muted-foreground">{assessment.date}</p>
                </div>
                <div className="flex items-center gap-2">
                  {assessment.status === "passed" ? (
                    <Badge className="bg-success/10 text-success border-success/20">
                      <CheckCircle2 className="w-3 h-3 mr-1" />
                      Passed
                    </Badge>
                  ) : assessment.status === "failed" ? (
                    <Badge className="bg-destructive/10 text-destructive border-destructive/20">
                      <XCircle className="w-3 h-3 mr-1" />
                      Needs Retake
                    </Badge>
                  ) : (
                    <Badge className="bg-muted text-muted-foreground">
                      <Clock className="w-3 h-3 mr-1" />
                      Pending
                    </Badge>
                  )}
                </div>
              </div>

              {assessment.status !== "pending" && (
                <>
                  <div className="flex items-center gap-4 mb-4">
                    <div className="text-3xl font-bold text-primary">{assessment.score}%</div>
                    <Progress value={assessment.score} className="flex-1 h-3" />
                  </div>
                  <div className="grid grid-cols-5 gap-2">
                    {assessment.details.map((detail, i) => (
                      <div key={i} className="text-center p-2 rounded-lg bg-secondary/50">
                        <div className="text-xs text-muted-foreground mb-1">{detail.section}</div>
                        <div className="text-sm font-bold">{detail.score}/{detail.max}</div>
                      </div>
                    ))}
                  </div>
                </>
              )}

              {assessment.status === "pending" && (
                <Button className="bg-gradient-to-r from-primary to-primary/80">
                  Start Assessment
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              )}

              {assessment.status === "failed" && (
                <Button variant="outline" className="mt-4">
                  Retake Assessment
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              )}
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
};
