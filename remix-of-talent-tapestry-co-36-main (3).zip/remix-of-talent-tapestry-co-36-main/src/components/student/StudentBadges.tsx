import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Award,
  Zap,
  Star,
  Shield,
  Code2,
  GitBranch,
  Users,
  Trophy,
  Target,
  Flame
} from "lucide-react";

interface BadgeItem {
  id: string;
  name: string;
  icon: React.ReactNode;
  description: string;
  earned: boolean;
  earnedDate?: string;
  progress?: number;
  category: "skill" | "achievement" | "quality" | "milestone";
}

const allBadges: BadgeItem[] = [
  {
    id: "1", name: "First Delivery", icon: <Trophy className="w-6 h-6" />,
    description: "Complete your first project deliverable",
    earned: true, earnedDate: "Dec 2024", category: "milestone"
  },
  {
    id: "2", name: "5-Sprint Streak", icon: <Flame className="w-6 h-6" />,
    description: "Complete 5 sprints consecutively without rejection",
    earned: true, earnedDate: "Jan 2025", category: "achievement"
  },
  {
    id: "3", name: "Quality Champion", icon: <Target className="w-6 h-6" />,
    description: "Maintain 90%+ quality score for 3 consecutive projects",
    earned: true, earnedDate: "Jan 2025", category: "quality"
  },
  {
    id: "4", name: "Full Stack Pro", icon: <Code2 className="w-6 h-6" />,
    description: "Deliver projects using both frontend and backend technologies",
    earned: true, earnedDate: "Jan 2025", category: "skill"
  },
  {
    id: "5", name: "Speed Demon", icon: <Zap className="w-6 h-6" />,
    description: "Deliver 3 projects ahead of schedule",
    earned: false, progress: 67, category: "achievement"
  },
  {
    id: "6", name: "Code Reviewer", icon: <GitBranch className="w-6 h-6" />,
    description: "Review code for 5 peer projects",
    earned: false, progress: 40, category: "skill"
  },
  {
    id: "7", name: "Team Leader", icon: <Users className="w-6 h-6" />,
    description: "Lead a team of 3+ on a project",
    earned: false, progress: 0, category: "milestone"
  },
  {
    id: "8", name: "Security Expert", icon: <Shield className="w-6 h-6" />,
    description: "Pass security audit on 3 projects with 95%+ score",
    earned: false, progress: 33, category: "quality"
  },
  {
    id: "9", name: "Client Favorite", icon: <Star className="w-6 h-6" />,
    description: "Receive 5-star rating from 5 different clients",
    earned: false, progress: 60, category: "achievement"
  },
  {
    id: "10", name: "10x Developer", icon: <Award className="w-6 h-6" />,
    description: "Complete 10 projects with 90%+ acceptance rate",
    earned: false, progress: 50, category: "milestone"
  }
];

const categoryColors: Record<string, string> = {
  skill: "from-blue-400 to-blue-500",
  achievement: "from-amber-400 to-amber-500",
  quality: "from-emerald-400 to-emerald-500",
  milestone: "from-purple-400 to-purple-500"
};

const categoryLabels: Record<string, string> = {
  skill: "Skill",
  achievement: "Achievement",
  quality: "Quality",
  milestone: "Milestone"
};

export const StudentBadges = () => {
  const earned = allBadges.filter(b => b.earned);
  const inProgress = allBadges.filter(b => !b.earned);

  return (
    <div className="space-y-6">
      {/* Summary */}
      <Card className="p-6 bg-gradient-to-r from-primary/10 to-accent/10 border-primary/20">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-bold mb-1">Your Badge Collection</h2>
            <p className="text-sm text-muted-foreground">
              {earned.length} earned • {inProgress.length} in progress
            </p>
          </div>
          <div className="flex items-center gap-2">
            <div className="text-3xl font-bold text-primary">{earned.length}</div>
            <div className="text-sm text-muted-foreground">/ {allBadges.length}</div>
          </div>
        </div>
      </Card>

      {/* Earned Badges */}
      <div>
        <h3 className="font-bold text-lg mb-3 flex items-center gap-2">
          <Award className="w-5 h-5 text-amber-500" />
          Earned Badges
        </h3>
        <div className="grid md:grid-cols-2 gap-3">
          {earned.map((badge) => (
            <Card key={badge.id} className="p-4 border-primary/20 bg-primary/5 hover:shadow-lg transition-all">
              <div className="flex items-center gap-4">
                <div className={`w-12 h-12 rounded-full bg-gradient-to-br ${categoryColors[badge.category]} flex items-center justify-center text-white`}>
                  {badge.icon}
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <span className="font-bold">{badge.name}</span>
                    <Badge className="text-[10px] bg-success/10 text-success border-success/20">✓ Earned</Badge>
                  </div>
                  <p className="text-xs text-muted-foreground">{badge.description}</p>
                  <p className="text-xs text-primary mt-1">{badge.earnedDate}</p>
                </div>
                <Badge variant="outline" className="text-xs capitalize">{categoryLabels[badge.category]}</Badge>
              </div>
            </Card>
          ))}
        </div>
      </div>

      {/* In Progress */}
      <div>
        <h3 className="font-bold text-lg mb-3 flex items-center gap-2">
          <Zap className="w-5 h-5 text-primary" />
          In Progress
        </h3>
        <div className="grid md:grid-cols-2 gap-3">
          {inProgress.map((badge) => (
            <Card key={badge.id} className="p-4 hover:shadow-lg transition-all">
              <div className="flex items-center gap-4">
                <div className={`w-12 h-12 rounded-full bg-gradient-to-br ${categoryColors[badge.category]} flex items-center justify-center text-white opacity-50`}>
                  {badge.icon}
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <span className="font-bold">{badge.name}</span>
                    <Badge variant="secondary" className="text-[10px]">{badge.progress}%</Badge>
                  </div>
                  <p className="text-xs text-muted-foreground mb-2">{badge.description}</p>
                  <Progress value={badge.progress} className="h-1.5" />
                </div>
                <Badge variant="outline" className="text-xs capitalize">{categoryLabels[badge.category]}</Badge>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
};
