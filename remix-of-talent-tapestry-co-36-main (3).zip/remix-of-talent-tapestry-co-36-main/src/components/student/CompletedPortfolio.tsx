import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  ExternalLink,
  Star,
  Code2,
  Calendar,
  Clock,
  CheckCircle2,
  GitBranch,
  Eye
} from "lucide-react";

interface Project {
  id: string;
  title: string;
  client: string;
  description: string;
  techStack: string[];
  completedDate: string;
  duration: string;
  rating: number;
  qualityScore: number;
  feedback: string;
  deliverables: string[];
}

const completedProjects: Project[] = [
  {
    id: "1",
    title: "E-commerce Payment Integration",
    client: "FinanceFlow",
    description: "Implemented Razorpay and Stripe payment gateway integration with webhook handling, refund management, and transaction logging.",
    techStack: ["Node.js", "Express", "Razorpay", "Stripe", "PostgreSQL"],
    completedDate: "Jan 22, 2025",
    duration: "7 days",
    rating: 5,
    qualityScore: 94,
    feedback: "Excellent work! Clean code, well-documented, delivered ahead of schedule.",
    deliverables: ["API endpoints", "Webhook handlers", "Test suite (96% coverage)", "API documentation"]
  },
  {
    id: "2",
    title: "User Authentication System",
    client: "TechCorp",
    description: "Built complete auth system with JWT, OAuth (Google, GitHub), role-based access control, and session management.",
    techStack: ["React", "Node.js", "JWT", "OAuth2", "Redis"],
    completedDate: "Jan 10, 2025",
    duration: "5 days",
    rating: 5,
    qualityScore: 91,
    feedback: "Great implementation of RBAC. Security best practices followed throughout.",
    deliverables: ["Auth module", "RBAC middleware", "Test suite", "Security docs"]
  },
  {
    id: "3",
    title: "Dashboard UI Components",
    client: "StartupHub",
    description: "Created reusable React component library with charts, tables, forms, and notification systems for admin dashboard.",
    techStack: ["React", "TypeScript", "Tailwind CSS", "Recharts", "Storybook"],
    completedDate: "Dec 28, 2024",
    duration: "5 days",
    rating: 4,
    qualityScore: 87,
    feedback: "Good components, well-structured. Minor improvements needed in accessibility.",
    deliverables: ["12 React components", "Storybook docs", "Unit tests", "Usage guide"]
  },
  {
    id: "4",
    title: "REST API for Inventory Management",
    client: "DataDrive",
    description: "Designed and implemented RESTful API for inventory tracking, stock alerts, and reporting with comprehensive documentation.",
    techStack: ["Node.js", "Express", "MongoDB", "Swagger"],
    completedDate: "Dec 15, 2024",
    duration: "10 days",
    rating: 5,
    qualityScore: 92,
    feedback: "Excellent API design. Documentation was thorough and examples were very helpful.",
    deliverables: ["REST API (24 endpoints)", "Swagger docs", "Test suite (92% coverage)", "Deployment guide"]
  },
  {
    id: "5",
    title: "Email Notification Service",
    client: "CloudNine Systems",
    description: "Built scalable email notification service with templates, scheduling, delivery tracking, and analytics dashboard.",
    techStack: ["Node.js", "Redis", "SendGrid", "Bull Queue"],
    completedDate: "Dec 5, 2024",
    duration: "4 days",
    rating: 5,
    qualityScore: 95,
    feedback: "Outstanding! The queue system is very well-designed. Exceeded expectations.",
    deliverables: ["Notification service", "Email templates", "Analytics API", "Operations docs"]
  }
];

export const CompletedPortfolio = () => {
  const avgRating = (completedProjects.reduce((sum, p) => sum + p.rating, 0) / completedProjects.length).toFixed(1);
  const avgQuality = Math.round(completedProjects.reduce((sum, p) => sum + p.qualityScore, 0) / completedProjects.length);

  return (
    <div className="space-y-6">
      {/* Summary */}
      <div className="grid grid-cols-4 gap-4">
        {[
          { label: "Completed Projects", value: completedProjects.length.toString(), icon: CheckCircle2 },
          { label: "Avg. Rating", value: avgRating, icon: Star },
          { label: "Avg. Quality", value: `${avgQuality}%`, icon: Code2 },
          { label: "Clients Served", value: "5", icon: GitBranch }
        ].map((stat, i) => (
          <Card key={i} className="p-4 text-center">
            <stat.icon className="w-6 h-6 mx-auto mb-2 text-primary" />
            <div className="text-2xl font-bold">{stat.value}</div>
            <div className="text-xs text-muted-foreground">{stat.label}</div>
          </Card>
        ))}
      </div>

      {/* Projects */}
      <div className="space-y-4">
        {completedProjects.map((project) => (
          <Card key={project.id} className="p-6 hover:shadow-lg transition-all">
            <div className="flex items-start justify-between mb-3">
              <div>
                <div className="flex items-center gap-3 mb-1">
                  <h3 className="text-lg font-bold">{project.title}</h3>
                  <div className="flex items-center gap-1">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star
                        key={i}
                        className={`w-4 h-4 ${
                          i < project.rating ? "fill-amber-400 text-amber-400" : "text-muted-foreground"
                        }`}
                      />
                    ))}
                  </div>
                </div>
                <p className="text-sm text-muted-foreground">
                  {project.client} • <Calendar className="w-3 h-3 inline" /> {project.completedDate} • <Clock className="w-3 h-3 inline" /> {project.duration}
                </p>
              </div>
              <Badge className="bg-success/10 text-success border-success/20">
                Quality: {project.qualityScore}%
              </Badge>
            </div>

            <p className="text-sm text-muted-foreground mb-3">{project.description}</p>

            <div className="flex flex-wrap gap-2 mb-3">
              {project.techStack.map((tech, i) => (
                <Badge key={i} variant="secondary" className="text-xs">{tech}</Badge>
              ))}
            </div>

            {/* Deliverables */}
            <div className="flex flex-wrap gap-2 mb-3">
              {project.deliverables.map((d, i) => (
                <div key={i} className="flex items-center gap-1 text-xs text-muted-foreground bg-secondary/50 px-2 py-1 rounded">
                  <CheckCircle2 className="w-3 h-3 text-success" />
                  {d}
                </div>
              ))}
            </div>

            {/* Client Feedback */}
            <div className="p-3 rounded-lg bg-secondary/30 border-l-4 border-primary/30">
              <p className="text-sm italic text-muted-foreground">"{project.feedback}"</p>
              <p className="text-xs text-primary mt-1 font-medium">— {project.client}</p>
            </div>

            <div className="flex gap-2 mt-4">
              <Button size="sm" variant="outline">
                <Eye className="mr-1 h-4 w-4" />
                View Details
              </Button>
              <Button size="sm" variant="outline">
                <ExternalLink className="mr-1 h-4 w-4" />
                View Code
              </Button>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
};
