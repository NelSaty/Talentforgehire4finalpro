import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  MessageSquare,
  Calendar,
  Star,
  Video,
  Clock,
  CheckCircle2,
  UserCheck
} from "lucide-react";

interface Mentor {
  name: string;
  role: string;
  expertise: string[];
  rating: number;
  sessionsCompleted: number;
  availability: string;
  nextSession?: string;
  assigned: boolean;
}

const mentors: Mentor[] = [
  {
    name: "Arjun Mehta",
    role: "Senior Steward",
    expertise: ["React", "Node.js", "System Design"],
    rating: 4.9,
    sessionsCompleted: 12,
    availability: "Mon, Wed, Fri",
    nextSession: "Feb 19, 2025 - 3:00 PM",
    assigned: true
  },
  {
    name: "Kavya Iyer",
    role: "Tech Lead Mentor",
    expertise: ["Python", "Machine Learning", "Data Engineering"],
    rating: 4.8,
    sessionsCompleted: 0,
    availability: "Tue, Thu",
    assigned: false
  },
  {
    name: "Rahul Verma",
    role: "Career Coach",
    expertise: ["Interview Prep", "Resume Review", "Soft Skills"],
    rating: 4.7,
    sessionsCompleted: 5,
    availability: "Daily",
    nextSession: "Feb 20, 2025 - 11:00 AM",
    assigned: true
  }
];

const upcomingSessions = [
  { mentor: "Arjun Mehta", topic: "Code Review: Payment API", date: "Feb 19, 3:00 PM", type: "video" },
  { mentor: "Rahul Verma", topic: "Mock Interview Practice", date: "Feb 20, 11:00 AM", type: "video" },
  { mentor: "Arjun Mehta", topic: "System Design Discussion", date: "Feb 24, 4:00 PM", type: "chat" }
];

export const MentorAssignment = () => {
  return (
    <div className="space-y-6">
      {/* Upcoming Sessions */}
      <Card className="p-6 bg-gradient-to-r from-primary/5 to-accent/5 border-primary/20">
        <h2 className="font-bold text-lg mb-4 flex items-center gap-2">
          <Calendar className="w-5 h-5 text-primary" />
          Upcoming Sessions
        </h2>
        <div className="space-y-3">
          {upcomingSessions.map((session, i) => (
            <div key={i} className="flex items-center justify-between p-3 rounded-lg bg-background border border-border">
              <div className="flex items-center gap-3">
                {session.type === "video" ? (
                  <Video className="w-5 h-5 text-primary" />
                ) : (
                  <MessageSquare className="w-5 h-5 text-primary" />
                )}
                <div>
                  <div className="font-medium text-sm">{session.topic}</div>
                  <div className="text-xs text-muted-foreground">with {session.mentor}</div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="text-xs text-muted-foreground flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  {session.date}
                </div>
                <Button size="sm" variant="outline">Join</Button>
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* Assigned Mentors */}
      <div>
        <h2 className="text-xl font-bold mb-4">Your Mentors</h2>
        <div className="space-y-4">
          {mentors.map((mentor, i) => (
            <Card key={i} className={`p-6 ${mentor.assigned ? "border-primary/20" : ""}`}>
              <div className="flex items-start gap-4">
                <div className="w-14 h-14 rounded-full bg-gradient-to-br from-primary to-primary/60 flex items-center justify-center text-xl font-bold text-primary-foreground">
                  {mentor.name.charAt(0)}
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-1">
                    <h3 className="text-lg font-bold">{mentor.name}</h3>
                    {mentor.assigned && (
                      <Badge className="bg-success/10 text-success border-success/20 text-xs">
                        <UserCheck className="w-3 h-3 mr-1" />
                        Assigned
                      </Badge>
                    )}
                  </div>
                  <p className="text-sm text-muted-foreground mb-2">{mentor.role}</p>
                  <div className="flex flex-wrap gap-2 mb-3">
                    {mentor.expertise.map((skill, j) => (
                      <Badge key={j} variant="secondary" className="text-xs">{skill}</Badge>
                    ))}
                  </div>
                  <div className="flex items-center gap-4 text-sm">
                    <div className="flex items-center gap-1">
                      <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                      <span className="font-semibold">{mentor.rating}</span>
                    </div>
                    <span className="text-muted-foreground">
                      {mentor.sessionsCompleted} sessions completed
                    </span>
                    <span className="text-muted-foreground">
                      Available: {mentor.availability}
                    </span>
                  </div>
                  {mentor.nextSession && (
                    <div className="mt-2 text-xs text-primary font-medium flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      Next: {mentor.nextSession}
                    </div>
                  )}
                </div>
                <div className="flex flex-col gap-2">
                  {mentor.assigned ? (
                    <>
                      <Button size="sm">
                        <MessageSquare className="mr-1 h-4 w-4" />
                        Message
                      </Button>
                      <Button size="sm" variant="outline">
                        <Calendar className="mr-1 h-4 w-4" />
                        Schedule
                      </Button>
                    </>
                  ) : (
                    <Button size="sm" variant="outline">
                      Request Mentor
                    </Button>
                  )}
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
};
