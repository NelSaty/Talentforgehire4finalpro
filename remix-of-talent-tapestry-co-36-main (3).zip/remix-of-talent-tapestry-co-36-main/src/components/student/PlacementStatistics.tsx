import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  TrendingUp,
  Users,
  Building2,
  DollarSign,
  Award,
  Briefcase,
  GraduationCap,
  BarChart3,
  Target,
  Star
} from "lucide-react";

const placementStats = {
  totalPlaced: 892,
  placementRate: 78,
  avgSalary: "₹4.2 LPA",
  topTierRate: 94,
  avgTimeToPlace: "3.5 months"
};

const topCompanies = [
  { name: "TechCorp India", hires: 45, avgPackage: "₹5.5 LPA", rating: 4.8 },
  { name: "StartupHub", hires: 32, avgPackage: "₹4.8 LPA", rating: 4.7 },
  { name: "FinanceFlow", hires: 28, avgPackage: "₹5.2 LPA", rating: 4.9 },
  { name: "DataDrive", hires: 24, avgPackage: "₹4.5 LPA", rating: 4.6 },
  { name: "CloudNine Systems", hires: 21, avgPackage: "₹5.8 LPA", rating: 4.8 }
];

const tierPlacement = [
  { tier: "Fast-Track", rate: 94, avgSalary: "₹6.5 LPA", color: "from-emerald-400 to-emerald-500" },
  { tier: "Lead", rate: 88, avgSalary: "₹5.2 LPA", color: "from-amber-400 to-amber-500" },
  { tier: "Associate", rate: 72, avgSalary: "₹4.0 LPA", color: "from-purple-400 to-purple-500" },
  { tier: "Contributor", rate: 45, avgSalary: "₹3.2 LPA", color: "from-blue-400 to-blue-500" },
  { tier: "Trainee", rate: 15, avgSalary: "₹2.5 LPA", color: "from-gray-400 to-gray-500" }
];

const skillDemand = [
  { skill: "React", demand: 92, openings: 34 },
  { skill: "Node.js", demand: 87, openings: 28 },
  { skill: "Python", demand: 85, openings: 26 },
  { skill: "TypeScript", demand: 82, openings: 22 },
  { skill: "AWS/Cloud", demand: 78, openings: 18 },
  { skill: "React Native", demand: 71, openings: 14 }
];

export const PlacementStatistics = () => {
  return (
    <div className="space-y-6">
      {/* Overview Stats */}
      <div className="grid grid-cols-5 gap-4">
        {[
          { label: "Total Placed", value: placementStats.totalPlaced, icon: Users, color: "text-primary" },
          { label: "Placement Rate", value: `${placementStats.placementRate}%`, icon: TrendingUp, color: "text-success" },
          { label: "Avg. Package", value: placementStats.avgSalary, icon: DollarSign, color: "text-primary" },
          { label: "Top Tier Rate", value: `${placementStats.topTierRate}%`, icon: Award, color: "text-amber-500" },
          { label: "Avg. Time", value: placementStats.avgTimeToPlace, icon: Target, color: "text-primary" }
        ].map((stat, i) => (
          <Card key={i} className="p-4 text-center">
            <stat.icon className={`w-6 h-6 mx-auto mb-2 ${stat.color}`} />
            <div className="text-xl font-bold">{stat.value}</div>
            <div className="text-xs text-muted-foreground">{stat.label}</div>
          </Card>
        ))}
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Placement by Tier */}
        <Card className="p-6">
          <h2 className="text-lg font-bold mb-4 flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-primary" />
            Placement by Tier
          </h2>
          <div className="space-y-4">
            {tierPlacement.map((tier, i) => (
              <div key={i} className="flex items-center gap-4">
                <div className={`w-8 h-8 rounded-full bg-gradient-to-br ${tier.color} flex-shrink-0`} />
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm font-semibold">{tier.tier}</span>
                    <span className="text-sm font-bold">{tier.rate}%</span>
                  </div>
                  <Progress value={tier.rate} className="h-2" />
                  <span className="text-xs text-muted-foreground">Avg: {tier.avgSalary}</span>
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* Top Hiring Companies */}
        <Card className="p-6">
          <h2 className="text-lg font-bold mb-4 flex items-center gap-2">
            <Building2 className="w-5 h-5 text-primary" />
            Top Hiring Companies
          </h2>
          <div className="space-y-3">
            {topCompanies.map((company, i) => (
              <div key={i} className="flex items-center justify-between p-3 rounded-lg border border-border hover:bg-secondary/50 transition-colors">
                <div>
                  <div className="font-semibold text-sm">{company.name}</div>
                  <div className="text-xs text-muted-foreground">{company.hires} hires • {company.avgPackage}</div>
                </div>
                <div className="flex items-center gap-1 text-sm">
                  <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                  <span className="font-semibold">{company.rating}</span>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* In-Demand Skills */}
      <Card className="p-6">
        <h2 className="text-lg font-bold mb-4 flex items-center gap-2">
          <Briefcase className="w-5 h-5 text-primary" />
          In-Demand Skills
        </h2>
        <div className="grid grid-cols-3 gap-4">
          {skillDemand.map((item, i) => (
            <div key={i} className="p-3 rounded-lg border border-border">
              <div className="flex items-center justify-between mb-2">
                <span className="font-semibold text-sm">{item.skill}</span>
                <Badge variant="secondary" className="text-xs">{item.openings} openings</Badge>
              </div>
              <Progress value={item.demand} className="h-2 mb-1" />
              <span className="text-xs text-muted-foreground">{item.demand}% demand</span>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
};
